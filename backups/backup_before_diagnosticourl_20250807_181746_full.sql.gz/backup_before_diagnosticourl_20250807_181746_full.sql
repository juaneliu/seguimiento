--
-- PostgreSQL database dump
--

-- Dumped from database version 14.18 (Ubuntu 14.18-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.18 (Ubuntu 14.18-0ubuntu0.22.04.1)

-- Started on 2025-08-07 18:17:47 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS tablero_estadistico_prod;
--
-- TOC entry 3433 (class 1262 OID 16384)
-- Name: tablero_estadistico_prod; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE tablero_estadistico_prod WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


\connect tablero_estadistico_prod

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 839 (class 1247 OID 16515)
-- Name: RolUsuario; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RolUsuario" AS ENUM (
    'INVITADO',
    'OPERATIVO',
    'SEGUIMIENTO',
    'ADMINISTRADOR'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 210 (class 1259 OID 16524)
-- Name: acuerdos_seguimiento; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acuerdos_seguimiento (
    id integer NOT NULL,
    "numeroSesion" text NOT NULL,
    "tipoSesion" text NOT NULL,
    "fechaSesion" timestamp(3) without time zone NOT NULL,
    "temaAgenda" text NOT NULL,
    "descripcionAcuerdo" text NOT NULL,
    responsable text NOT NULL,
    area text NOT NULL,
    "fechaCompromiso" timestamp(3) without time zone NOT NULL,
    prioridad text NOT NULL,
    estado text DEFAULT 'Pendiente'::text NOT NULL,
    observaciones text,
    "fechaCreacion" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "fechaActualizacion" timestamp(3) without time zone NOT NULL,
    "creadoPor" text
);


--
-- TOC entry 209 (class 1259 OID 16523)
-- Name: acuerdos_seguimiento_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.acuerdos_seguimiento_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3434 (class 0 OID 0)
-- Dependencies: 209
-- Name: acuerdos_seguimiento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.acuerdos_seguimiento_id_seq OWNED BY public.acuerdos_seguimiento.id;


--
-- TOC entry 224 (class 1259 OID 16602)
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    usuario_id integer NOT NULL,
    accion text NOT NULL,
    tabla text NOT NULL,
    registro_id integer,
    valores_anteriores jsonb,
    valores_nuevos jsonb,
    direccion_ip text,
    fecha_creacion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 16601)
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3435 (class 0 OID 0)
-- Dependencies: 223
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- TOC entry 226 (class 1259 OID 32884)
-- Name: diagnosticos_entes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.diagnosticos_entes (
    id integer NOT NULL,
    "nombreActividad" text NOT NULL,
    "entePublico" text NOT NULL,
    actividad text NOT NULL,
    "solicitudUrl" text,
    "respuestaUrl" text,
    "unidadAdministrativa" text NOT NULL,
    evaluacion double precision NOT NULL,
    observaciones text,
    acciones jsonb,
    estado text DEFAULT 'En Proceso'::text NOT NULL,
    "fechaCreacion" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "fechaActualizacion" timestamp(3) without time zone NOT NULL,
    "creadoPor" text,
    organo text DEFAULT 'Central'::text NOT NULL,
    poder text DEFAULT 'Ejecutivo'::text NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 32883)
-- Name: diagnosticos_entes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.diagnosticos_entes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3436 (class 0 OID 0)
-- Dependencies: 225
-- Name: diagnosticos_entes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.diagnosticos_entes_id_seq OWNED BY public.diagnosticos_entes.id;


--
-- TOC entry 212 (class 1259 OID 16535)
-- Name: diagnosticos_municipales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.diagnosticos_municipales (
    id integer NOT NULL,
    "nombreActividad" text NOT NULL,
    municipio text NOT NULL,
    actividad text NOT NULL,
    "solicitudUrl" text,
    "respuestaUrl" text,
    "unidadAdministrativa" text NOT NULL,
    evaluacion double precision NOT NULL,
    observaciones text,
    acciones jsonb,
    estado text DEFAULT 'En Proceso'::text NOT NULL,
    "fechaCreacion" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "fechaActualizacion" timestamp(3) without time zone NOT NULL,
    "creadoPor" text
);


--
-- TOC entry 211 (class 1259 OID 16534)
-- Name: diagnosticos_municipales_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.diagnosticos_municipales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3437 (class 0 OID 0)
-- Dependencies: 211
-- Name: diagnosticos_municipales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.diagnosticos_municipales_id_seq OWNED BY public.diagnosticos_municipales.id;


--
-- TOC entry 214 (class 1259 OID 16546)
-- Name: directorio_oic; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directorio_oic (
    id integer NOT NULL,
    "oicNombre" text NOT NULL,
    puesto text NOT NULL,
    nombre text NOT NULL,
    "correoElectronico" text NOT NULL,
    telefono text,
    direccion text,
    entidad jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 216 (class 1259 OID 16556)
-- Name: directorio_oic_entes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directorio_oic_entes (
    id integer NOT NULL,
    "directorioOICId" integer NOT NULL,
    "entePublicoId" integer NOT NULL
);


--
-- TOC entry 215 (class 1259 OID 16555)
-- Name: directorio_oic_entes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.directorio_oic_entes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3438 (class 0 OID 0)
-- Dependencies: 215
-- Name: directorio_oic_entes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.directorio_oic_entes_id_seq OWNED BY public.directorio_oic_entes.id;


--
-- TOC entry 213 (class 1259 OID 16545)
-- Name: directorio_oic_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.directorio_oic_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3439 (class 0 OID 0)
-- Dependencies: 213
-- Name: directorio_oic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.directorio_oic_id_seq OWNED BY public.directorio_oic.id;


--
-- TOC entry 218 (class 1259 OID 16563)
-- Name: entes_publicos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entes_publicos (
    id integer NOT NULL,
    nombre text NOT NULL,
    "ambitoGobierno" text NOT NULL,
    "poderGobierno" text NOT NULL,
    "controlOIC" boolean DEFAULT false NOT NULL,
    "controlTribunal" boolean DEFAULT false NOT NULL,
    sistema1 boolean DEFAULT false NOT NULL,
    sistema2 boolean DEFAULT false NOT NULL,
    sistema3 boolean DEFAULT false NOT NULL,
    sistema6 boolean DEFAULT false NOT NULL,
    entidad jsonb NOT NULL,
    municipio text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 217 (class 1259 OID 16562)
-- Name: entes_publicos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.entes_publicos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3440 (class 0 OID 0)
-- Dependencies: 217
-- Name: entes_publicos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.entes_publicos_id_seq OWNED BY public.entes_publicos.id;


--
-- TOC entry 220 (class 1259 OID 16579)
-- Name: seguimientos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seguimientos (
    id integer NOT NULL,
    "acuerdoId" integer NOT NULL,
    seguimiento text NOT NULL,
    accion text NOT NULL,
    "fechaSeguimiento" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "fechaCreacion" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "fechaActualizacion" timestamp(3) without time zone NOT NULL,
    "creadoPor" text
);


--
-- TOC entry 219 (class 1259 OID 16578)
-- Name: seguimientos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seguimientos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3441 (class 0 OID 0)
-- Dependencies: 219
-- Name: seguimientos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.seguimientos_id_seq OWNED BY public.seguimientos.id;


--
-- TOC entry 222 (class 1259 OID 16590)
-- Name: usuarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    email text NOT NULL,
    nombre text NOT NULL,
    apellido text NOT NULL,
    password text,
    rol public."RolUsuario" DEFAULT 'INVITADO'::public."RolUsuario" NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    "ultimoAcceso" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 221 (class 1259 OID 16589)
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3442 (class 0 OID 0)
-- Dependencies: 221
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- TOC entry 3214 (class 2604 OID 16527)
-- Name: acuerdos_seguimiento id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acuerdos_seguimiento ALTER COLUMN id SET DEFAULT nextval('public.acuerdos_seguimiento_id_seq'::regclass);


--
-- TOC entry 3238 (class 2604 OID 16605)
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- TOC entry 3240 (class 2604 OID 32887)
-- Name: diagnosticos_entes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diagnosticos_entes ALTER COLUMN id SET DEFAULT nextval('public.diagnosticos_entes_id_seq'::regclass);


--
-- TOC entry 3217 (class 2604 OID 16538)
-- Name: diagnosticos_municipales id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diagnosticos_municipales ALTER COLUMN id SET DEFAULT nextval('public.diagnosticos_municipales_id_seq'::regclass);


--
-- TOC entry 3220 (class 2604 OID 16549)
-- Name: directorio_oic id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directorio_oic ALTER COLUMN id SET DEFAULT nextval('public.directorio_oic_id_seq'::regclass);


--
-- TOC entry 3222 (class 2604 OID 16559)
-- Name: directorio_oic_entes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directorio_oic_entes ALTER COLUMN id SET DEFAULT nextval('public.directorio_oic_entes_id_seq'::regclass);


--
-- TOC entry 3223 (class 2604 OID 16566)
-- Name: entes_publicos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entes_publicos ALTER COLUMN id SET DEFAULT nextval('public.entes_publicos_id_seq'::regclass);


--
-- TOC entry 3231 (class 2604 OID 16582)
-- Name: seguimientos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seguimientos ALTER COLUMN id SET DEFAULT nextval('public.seguimientos_id_seq'::regclass);


--
-- TOC entry 3234 (class 2604 OID 16593)
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- TOC entry 3411 (class 0 OID 16524)
-- Dependencies: 210
-- Data for Name: acuerdos_seguimiento; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.acuerdos_seguimiento (id, "numeroSesion", "tipoSesion", "fechaSesion", "temaAgenda", "descripcionAcuerdo", responsable, area, "fechaCompromiso", prioridad, estado, observaciones, "fechaCreacion", "fechaActualizacion", "creadoPor") FROM stdin;
3	01/2025	Sesión Ordinaria	2025-01-21 00:00:00	PUNTO (5) Presentación y en su caso aprobación de la Distribución del Presupuesto del año 2025 para la Secretaría Ejecutiva del Sistema Anticorrupción del Estado de Morelos	Se aprueba la Distribución del Presupuesto del año 2025 para la Secretaría Ejecutiva del Sistema	C.P. Priscila Hernández Cruz 	Administrativa	2025-01-22 00:00:00	Alta	Completado	Publicación en el Periodico Oficial "Tierra y Libertad"\nhttp://periodico.morelos.gob.mx/obtenerPDF/2025/6409.pdf 	2025-07-07 17:28:04.768	2025-07-07 17:44:56.229	\N
4	01/2025	Sesión Ordinaria	2025-01-21 00:00:00	PUNTO (5) Presentación y en su caso aprobación de la Distribución del Presupuesto del año 2025 para la Secretaría Ejecutiva del Sistema Anticorrupción del Estado de Morelos	Cualquier cambio, adhesión y/o modificación correspondiente a los tabuladores de los salarios de los trabajadores al servicio de la Secretaria Ejecutiva del Sistema Estatal Anticorrupción, tendrá que ser autorizada previamente por el Comité Coordinador	Secretaría Técnica	SAEM	2025-01-22 00:00:00	Media	Completado		2025-07-07 17:35:50.644	2025-07-07 17:45:08.341	\N
9	01/2025	Sesión Ordinaria	2025-01-21 00:00:00	PUNTO (5) Presentación y en su caso aprobación de la Distribución del Presupuesto del año 2025 para la Secretaría Ejecutiva del Sistema Anticorrupción del Estado de Morelos	Se instruye al Secretario Técnico, para que realice una proyección de mejora salarial primeramente con relación al presupuesto de egresos, que permita el análisis integral y valorar su viabilidad por parte del Comité Coordinador, en diversa sesión. 	Secretaría Técnica	SAEM	2025-04-22 00:00:00	Alta	En progreso	\N	2025-07-07 20:57:56.808	2025-07-07 20:57:56.736	\N
15	01/2025	Sesión Ordinaria	2025-01-21 00:00:00	PUNTO (7) Presentación y en su caso Autorización de contratación de personal, para la plaza de la Unidad de Riesgos y Política Pública de la Secretaría Ejecutiva.\t\t\t\t\t	Queda notificado del presente acuerdo el Secretario Técnico para su conocimiento, atención y seguimiento, para todos los efectos legales y/o administrativos que en el ámbito de su competencia corresponda, así como para que realice la presentación de manera particular con cada integrante del Comité Coordinador de la nueva Titular de la Unidad de Riesgos y Política Pública de la Secretaría Ejecutiva del Sistema Anticorrupción del Estado de Morelos, para que tengan conocimiento de quién se encuentra al frente.	Secretaría Técnica	SAEM	2025-01-22 00:00:00	Alta	Completado	Tomando en consideración la agenda de los Integrantes del Órgano de Gobierno, se realizó la presentación de la Lic. Eréndira Vázquez Domínguez, con cada uno de los Titulares.	2025-07-07 21:39:46.202	2025-07-07 21:39:46.131	\N
16	01/2025	Sesión Ordinaria	2025-01-21 00:00:00	PUNTO (8) Presentación y en su caso Aprobación de la contratación de prestación de servicios para auxiliar en los trabajos del Programa de Interconexión de la Plataforma Digital y actividades inherentes del Programa de Trabajo Anual del Comité Coordinador. \t\t\t\t\t	Se aprueba la contratación de prestación de servicios profesionales para auxiliar en los trabajos del Programa de Interconexión de la Plataforma Digital y actividades inherentes del Programa de Trabajo Anual del Comité Coordinador, con una vigencia hasta el treinta y uno de diciembre de dos mil veinticinco, de los CC. JOSÉ ANTONIO ÁVALOS GONZALEZ, ANGIE BETSABE TORRES SÁNCHEZ, SAMAEL LEONARDO SÁNCHEZ SANTIAGO, KAREN ESPARZA GÓMEZ, DIEGO EMILIANO JASSO VILLEGAS, OSCAR ÁLVAREZ SALGADO, GABRIEL LÓPEZ RAMOS, WALTER GÓMEZ SALGADO Y LILIANA PÉREZ SÁNCHEZ. 	Secretaría Técnica	SAEM	2025-12-31 00:00:00	Alta	En progreso	"*Los CC. JOSÉ ANTONIO ÁVALOS GONZALEZ, ANGIE BETSABE TORRES SÁNCHEZ, SAMAEL LEONARDO SÁNCHEZ SANTIAGO y GABRIEL LÓPEZ RAMOS, se encuentran a cargo de los  trabajos del Programa de Interconexión de la Plataforma Digital.\n*Los CC. KAREN ESPARZA GÓMEZ, DIEGO EMILIANO JASSO VILLEGAS, OSCAR ÁLVAREZ SALGADO,  WALTER GÓMEZ SALGADO Y LILIANA PÉREZ SÁNCHEZ, se encuentran a cargo de actividades inherentes del Programa de Trabajo Anual del Comité Coordinador. "\n	2025-07-07 21:48:21.136	2025-07-07 21:48:21.135	\N
10	01/2025	Sesión Ordinaria	2025-01-21 00:00:00	PUNTO (5) Presentación y en su caso aprobación de la Distribución del Presupuesto del año 2025 para la Secretaría Ejecutiva del Sistema Anticorrupción del Estado de Morelos\t\t\t\t\t	Se instruye al Secretario Técnico, para que dentro del ámbito de sus atribuciones, realice las acciones que permitan lograr la inclusión de los trabajadores al Instituto competente para que gocen de la atención médica y de los derechos inherentes, partiendo del antecedente jurídico y situación actual del problema planteado.	Secretaría Técnica	SAEM	2025-07-08 00:00:00	Alta	En progreso	\N	2025-07-07 21:03:21.945	2025-07-07 21:03:21.87	\N
11	01/2025	Sesión Ordinaria	2025-01-21 00:00:00	PUNTO (5) Presentación y en su caso aprobación de la Distribución del Presupuesto del año 2025 para la Secretaría Ejecutiva del Sistema Anticorrupción del Estado de Morelos	Se instruye para que dentro del ámbito de las facultades de la Secretaria Ejecutiva, se lleve a cabo la solicitud correspondiente al H. Congreso del Estado de Morelos, a efecto de informar y solicitar a la integración del Comité de Participación Ciudadana.	Secretaría Técnica	SAEM	2025-01-21 00:00:00	Alta	Completado	\N	2025-07-07 21:08:46.677	2025-07-07 21:08:46.676	\N
12	01/2025	Sesión Ordinaria	2025-01-21 00:00:00	PUNTO (5) Presentación y en su caso aprobación de la Distribución del Presupuesto del año 2025 para la Secretaría Ejecutiva del Sistema Anticorrupción del Estado de Morelos	A efecto de allegar a la ciudadanía en general la información de las actividades, así como las funciones y responsabilidades que le competen y realiza el Sistema Anticorrupción del Estado de Morelos, se instruye para que en el ámbito de las posibilidades de la Secretaria Ejecutiva, se implementen las acciones que permitan una mayor difusión del Sistema Anticorrupción del Estado de Morelos. 	Secretaría Técnica	SAEM	2025-01-21 00:00:00	Alta	Completado	Semanalmente la Secretaría Ejecutiva, realiza la difusión de cápsulas informativas.	2025-07-07 21:12:49.251	2025-07-07 21:19:15.523	\N
13	01/2025	Sesión Ordinaria	2025-01-21 00:00:00	PUNTO (6) Presentación y en su caso aprobación del Informe de la Cuenta Pública Anual 2024.\t\t\t\t\t	El Órgano de Gobierno tiene a bien aprobar El Informe de Cuenta Pública correspondiente a las actividades del Ejercicio Fiscal del año dos mil veinticuatro, correspondiente a la Secretaría Ejecutiva del Sistema Anticorrupción del Estado de Morelos.	C.P. Priscila Hernández Cruz 	Administrativa	2025-01-21 00:00:00	Alta	Completado	\N	2025-07-07 21:21:49.712	2025-07-07 21:21:49.71	\N
14	01/2025	Sesión Ordinaria	2025-01-21 00:00:00	PUNTO (7) Presentación y en su caso Autorización de contratación de personal, para la plaza de la Unidad de Riesgos y Política Pública de la Secretaría Ejecutiva.\t\t\t\t\t	Se autoriza la contratación de ERÉNDIRA VÁZQUEZ DOMÍNGUEZ, para ocupar la plaza de la Unidad de Riesgos y Política Pública de la Secretaría Ejecutiva del Sistema Anticorrupción del Estado de Morelos, con la temporalidad de tres meses, misma que podrá renovarse por parte del Comité Coordinador. 	Secretaría Técnica	SAEM	2025-04-22 00:00:00	Alta	Completado	\N	2025-07-07 21:34:41.158	2025-07-07 21:34:41.084	\N
17	01/2025	Sesión Ordinaria	2025-01-21 00:00:00	PUNTO (9) Presentación y en su caso Autorización del Programa de Capacitación, así como autorización para continuar con su implementación en coordinación con el Centro de Estudios en Materia Administrativa del Tribunal de Justicia Administrativa del Estado de Morelos. \t\t\t\t\t	Se aprueba el Programa de Capacitación, así como la continuación con su implementación en coordinación con el Centro de Estudios en Materia Administrativa del Tribunal de Justicia Administrativa del Estado de Morelos.	Secretaría Técnica	SAEM	2025-08-15 00:00:00	Alta	En progreso	\N	2025-07-07 21:51:09.18	2025-07-07 21:51:09.11	\N
\.


--
-- TOC entry 3425 (class 0 OID 16602)
-- Dependencies: 224
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, usuario_id, accion, tabla, registro_id, valores_anteriores, valores_nuevos, direccion_ip, fecha_creacion) FROM stdin;
4	2	LOGIN_EXITOSO	usuarios	2	\N	\N	::ffff:127.0.0.1	2025-07-04 19:19:33.052
5	2	LOGIN_EXITOSO	usuarios	2	\N	\N	::ffff:127.0.0.1	2025-07-04 19:19:39.341
6	2	LOGIN_EXITOSO	usuarios	2	\N	\N	::ffff:127.0.0.1	2025-07-04 19:21:21.938
7	2	ACCEDER_AUDITORIA	sistema	\N	\N	\N	::ffff:127.0.0.1	2025-07-04 19:21:21.983
8	2	PRUEBA_AUDITORIA	sistema	\N	\N	\N	127.0.0.1	2025-07-04 21:22:59.736
9	2	PRUEBA_AUDITORIA	sistema	\N	\N	\N	127.0.0.1	2025-07-04 21:25:34.311
10	2	PRUEBA_AUDITORIA	sistema	\N	\N	\N	127.0.0.1	2025-07-04 21:30:15.843
11	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	::ffff:127.0.0.1	2025-07-04 21:30:38.331
12	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	::ffff:127.0.0.1	2025-07-04 21:31:28.295
13	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	::ffff:127.0.0.1	2025-07-04 21:31:54.81
14	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.200.150	2025-07-04 21:33:05.339
15	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	::ffff:127.0.0.1	2025-07-04 21:37:56.403
16	3	ACCEDER_AUDITORIA	sistema	\N	\N	\N	::ffff:127.0.0.1	2025-07-04 21:37:58.423
17	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	::ffff:127.0.0.1	2025-07-04 21:39:06.415
18	3	ACCEDER_AUDITORIA	sistema	\N	\N	\N	::ffff:127.0.0.1	2025-07-04 21:39:08.886
19	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.187.89	2025-07-07 14:54:54.958
20	3	CREAR_USUARIO	usuarios	4	\N	{"rol": "ADMINISTRADOR", "email": "daniela.madrigal@saem.gob.mx", "nombre": "Daniela", "apellido": "Madrigal"}	189.225.187.89	2025-07-07 14:55:37.433
21	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.187.89	2025-07-07 14:55:40.529
22	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.187.89	2025-07-07 14:56:58.662
23	3	CREAR_USUARIO	usuarios	5	\N	{"rol": "OPERATIVO", "email": "karen.esparza@saem.gob.mx", "nombre": "Karen", "apellido": "Espazar"}	189.225.187.89	2025-07-07 14:57:26.66
24	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.187.89	2025-07-07 14:57:29.735
25	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.195.135	2025-07-07 15:26:19.872
26	3	ACCEDER_AUDITORIA	sistema	\N	\N	\N	189.225.195.135	2025-07-07 15:26:23.462
27	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.195.135	2025-07-07 15:50:06.776
28	3	ACCEDER_AUDITORIA	sistema	\N	\N	\N	189.225.195.135	2025-07-07 15:50:08.553
29	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.172.25	2025-07-09 16:10:59.551
30	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.172.25	2025-07-09 16:16:06.275
31	3	ACCEDER_AUDITORIA	sistema	\N	\N	\N	189.225.172.25	2025-07-09 16:17:22.915
32	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.172.25	2025-07-09 16:21:49.825
33	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.172.25	2025-07-09 16:23:33.675
34	3	CREAR_USUARIO	usuarios	6	\N	{"rol": "OPERATIVO", "email": "karen.esparza@saem.gob.mx", "nombre": "Karen ", "apellido": "Esparza"}	189.225.172.25	2025-07-09 16:24:53.212
35	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.172.25	2025-07-09 16:24:56.256
36	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.172.25	2025-07-10 16:01:18.845
37	3	ACCEDER_AUDITORIA	sistema	\N	\N	\N	189.225.172.25	2025-07-10 16:01:22.078
38	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.172.25	2025-07-10 18:26:26.325
39	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.172.25	2025-07-10 18:39:18.448
40	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.33.208	2025-08-04 20:29:33.245
41	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.33.208	2025-08-04 21:28:30.56
42	3	CREAR_USUARIO	usuarios	7	\N	{"rol": "OPERATIVO", "email": "diego.jasso@saem.gob.mx", "nombre": "Diego", "apellido": "Jasso"}	189.225.33.208	2025-08-04 21:33:48.54
43	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.33.208	2025-08-04 21:33:51.58
44	3	CONSULTAR_USUARIOS	usuarios	\N	\N	\N	189.225.39.103	2025-08-06 16:05:20.871
\.


--
-- TOC entry 3427 (class 0 OID 32884)
-- Dependencies: 226
-- Data for Name: diagnosticos_entes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.diagnosticos_entes (id, "nombreActividad", "entePublico", actividad, "solicitudUrl", "respuestaUrl", "unidadAdministrativa", evaluacion, observaciones, acciones, estado, "fechaCreacion", "fechaActualizacion", "creadoPor", organo, poder) FROM stdin;
7	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Aeropuerto de Cuernavaca S.A. de C.V.	Diagnóstico	https://drive.google.com/file/d/1AK429Iy1gsGmdakmcY-L0olDEzbm_62z/view	https://drive.google.com/test8-resp	Dirección de Administración 	30		[]	En Proceso	2025-08-07 14:42:20.834	2025-08-07 14:42:22.943	\N	Descentralizado	Ejecutivo
8	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Consejería Jurídica	Diagnóstico	https://drive.google.com/test8	https://drive.google.com/test5-resp	Dirección de Seguridad	60	ninguna	[{"id": "accion-1-1754585443259", "urlAccion": "https://drive.google.com/test8", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-08-29"}]	En Proceso	2025-08-07 16:51:02.407	2025-08-07 16:51:02.942	\N	Central	Ejecutivo
9	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Centro Morelense de las Artes	Índice	https://drive.google.com/test8	https://drive.google.com/test8-resp	Dirección de Seguridad	45	Ninguna	[]	En Proceso	2025-08-07 16:59:24.902	2025-08-07 16:59:25.498	\N	Central	Legislativo
\.


--
-- TOC entry 3413 (class 0 OID 16535)
-- Dependencies: 212
-- Data for Name: diagnosticos_municipales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.diagnosticos_municipales (id, "nombreActividad", municipio, actividad, "solicitudUrl", "respuestaUrl", "unidadAdministrativa", evaluacion, observaciones, acciones, estado, "fechaCreacion", "fechaActualizacion", "creadoPor") FROM stdin;
4	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal	Amacuzac	Diagnóstico	https://drive.google.com/file/d/1bHT0jjLaR6ktTXSkcIJ0ssHF2oFvYcXf/view	https://drive.google.com/file/d/113kWOwidd-Gg3EV-J3-v9yXaoJDw4SFY/view	Contraloria Muncipal	100	Se dio respuesta a la acción con el oficio. https://drive.google.com/file/d/120hV3SLU-izGtx41P15NDiaJZ7BWq33f/view	[{"id": "accion-1-1754337599049", "urlAccion": "https://drive.google.com/file/d/1VqLLRQKFn8Ip0HrnyWZ6UX2Z2xWti4-U/view", "completada": true, "descripcion": "Invitación", "fechaLimite": "2025-05-27"}]	Completado	2025-08-04 20:23:09.141	2025-08-04 20:23:09.141	\N
55	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Miacatlán	Diagnóstico	https://drive.google.com/file/d/1i4y_wiqVoTkfDrxJvF17jCzj4Gemx36o/view?usp=drive_link	https://drive.google.com/file/d/1tDFBYEnxQoS_IgqbOHaEpk24bsOgByo6/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:22:51.621	2025-08-05 21:22:51.621	\N
3	9. Indicador de Denuncias no pendientes de atención	Amacuzac	Indicador	https://drive.google.com/file/d/1WHu0WMJCL69bTRJkv_n-QHOzM0-hJQNn/view?usp=drive_link	https://drive.google.com/file/d/1WHu0WMJCL69bTRJkv_n-QHOzM0-hJQNn/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-04 19:53:20.835	2025-08-04 22:02:38.285	\N
11	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Axochiapan	Diagnóstico	https://drive.google.com/file/d/1OsJLrXab37ouPNz_c3zfgavVd8Pt3EjF/view?usp=drive_link	https://drive.google.com/file/d/1k_MNzedBa6RuApvP50O3ufOkJp3utkg0/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-4-1754417873900", "urlAccion": "https://drive.google.com/file/d/1-R5vz4meV-63YhsWwLaRxYsSLvxIkq-o/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-19"}]	Completado	2025-08-05 18:19:00.298	2025-08-05 18:19:00.298	\N
1	17. Diagnóstico relativo a las administraciones públicas central y paraestatal, que abrieron espacios de participación ciudadana, en temas de asignación del presupuesto o asuntos financieros o hacendarios	Amacuzac	Diagnóstico	https://drive.google.com/test8	https://drive.google.com/test5-resp	Dirección de Obras Públicas	100	ninguna	[]	Completado	2025-07-09 16:28:12.196	2025-08-04 22:03:39.447	\N
6	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Atlatlahucan	Diagnóstico	https://drive.google.com/file/d/1r0VOAWaGLoMJFypI8N2BckwIXxSiGA-O/view?usp=drive_link  https://drive.google.com/file/d/1IbdYcaal1BZIOHMXZwmzUNQcZU0_sEui/view?usp=drive_link"	https://drive.google.com/file/d/1P29LJcWFi32bTko4v8T9qODuKgv7C-Hr/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-04 22:27:05.271	2025-08-04 22:27:05.271	\N
7	17. Diagnóstico relativo a las administraciones públicas central y paraestatal, que abrieron espacios de participación ciudadana, en temas de asignación del presupuesto o asuntos financieros o hacendarios	Atlatlahucan	Diagnóstico	https://saem.gob.mx	https://saem.gob.mx	Contraloria Municipal	0	\N	[{"id": "accion-2-1754347009737", "urlAccion": "https://drive.google.com/file/d/1Ee3HKjot5VoFp4b1CzZhIK5_Dl7WI_GF/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-21"}]	Pendiente	2025-08-04 22:37:46.323	2025-08-04 22:37:46.323	\N
8	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Atlatlahucan	Diagnóstico	https://drive.google.com/file/d/1NhKpVLKuf3CZZK0ncrQWdRYw6po3AiGn/view?usp=drive_link	https://drive.google.com/file/d/1V7SyTiVADQIMpcDtLwYvWv6OpQqYIAgN/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 16:42:37.635	2025-08-05 16:42:37.635	\N
9	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Atlatlahucan	Diagnóstico	https://drive.google.com/file/d/1M7w_6jCRq8SY3oQtnGISxRbYGium4bCh/view?usp=drive_link	https://drive.google.com/file/d/1uhyl0svFxL9-KCJKJWcfn-wUenj1Ca3P/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 17:50:17.282	2025-08-05 17:50:17.282	\N
10	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Axochiapan	Diagnóstico	https://drive.google.com/file/d/154Y7h7OO19BWqXf8_cPk7opUe-vFZ59E/view?usp=drive_link	https://drive.google.com/file/d/1YikCQyF6s_yKX_4uabvywBylNJxUTdjP/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-3-1754416307598", "urlAccion": "https://drive.google.com/file/d/13OmHkroEZm7EZazArEoBPG5l4GRO7F98/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-27"}]	Completado	2025-08-05 17:53:36.01	2025-08-05 17:53:36.01	\N
5	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Amacuzac	Diagnóstico	https://drive.google.com/file/d/1jsaYutZqmBJQqySs2Dgx-ONXXmY3e9SZ/view?usp=drive_link	https://drive.google.com/file/d/1wV8xLROEsaarEUiVgR8SFRKj721XLNgj/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-1-1754345082225", "urlAccion": "https://drive.google.com/file/d/1HHX8IRXIT06wAGwzhsIuPw8DoThTAS5O/view?usp=sharing                                                             https://drive.google.com/file/d/14L9Ksb-kdW7NiZXm1sra-qVXzTZ60Jgf/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-19"}]	Completado	2025-08-04 22:07:18.26	2025-08-05 18:27:33.047	\N
12	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Axochiapan	Diagnóstico	https://drive.google.com/file/d/1Rz_xxi_P6lMAyLesT_tBF47LD-AizLeI/view?usp=sharing	https://drive.google.com/file/d/1T1DVGwrQlKsIExdJzemoL8RhwBjFgWso/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 18:21:15.871	2025-08-05 18:21:15.871	\N
13	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Ayala	Diagnóstico	https://drive.google.com/file/d/11Mbz6z_30APjNfESSir7UpdF6Utvud2K/view?usp=drive_link  https://drive.google.com/file/d/1pCJwb-UQy3_2RW_SRD0IPXdtEKDc61ES/view?usp=drive_link	https://saem.gob.mx	Contraloria Municipal	0	\N	[{"id": "accion-5-1754418548823", "urlAccion": "https://drive.google.com/file/d/18_j4h6sp9LLFzS9xq3IsvyYne9hVRwQB/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-20"}]	Pendiente	2025-08-05 18:29:38.295	2025-08-05 18:29:38.295	\N
2	9. Indicador de Denuncias no pendientes de atención	Axochiapan	Indicador	https://saem.gob.mx	https://drive.google.com/file/d/1jAYq_BrlT4IvK9nedrvoK7MCOjzw6-Zo/view?usp=drive_link	Contraloria Municipal	100	Ninguna	[]	Completado	2025-07-10 15:59:01.457	2025-08-05 20:29:11.459	\N
14	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Ayala	Diagnóstico	https://drive.google.com/file/d/1bvx2iWBOSnhhfocIzgKRSqVWTQtghX93/view?usp=drive_link	https://drive.google.com/file/d/1kiY7QJzLHDuIG3l4uwsXxiQ8J0WEJrg3/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-6-1754418616160", "urlAccion": "https://drive.google.com/file/d/1TnCxIpOHC6AVSJBxxiprCZah0Ii3v1XG/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-20"}]	Completado	2025-08-05 18:31:30.125	2025-08-05 18:31:30.125	\N
15	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Ayala	Diagnóstico	https://drive.google.com/file/d/1TmI_AZMUP1yT9QZvBSWgY2v0ePAlK01n/view?usp=drive_link	https://saem.gob.mx	Contraloria Municipal	0	\N	[]	Pendiente	2025-08-05 18:32:16.785	2025-08-05 18:32:16.785	\N
25	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Cuautla	Diagnóstico	https://drive.google.com/file/d/10qvGS2WHxvSpcH2yVfNLVqLzgucdArs8/view?usp=drive_link	https://drive.google.com/file/d/1AKECVgw4i9hbhg7TYW2AgNQD-pbqCIS6/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-10-1754424053476", "urlAccion": "https://drive.google.com/file/d/1s-4Vu5KPP5xNwnVa_O5mjaJZTa6zJVn1/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-27"}]	Completado	2025-08-05 20:01:20.446	2025-08-05 20:01:20.446	\N
16	9. Indicador de Denuncias no pendientes de atención	Coatetelco	Diagnóstico	https://saem.gob.mx	https://drive.google.com/file/d/1Yh29WYmjiGyKV7dClxfRD_U6CEeTttTR/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 18:33:40.115	2025-08-05 18:46:49.766	\N
17	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Coatetelco	Diagnóstico	https://saem.gob.mx	https://drive.google.com/file/d/1pO_2txNUuSBlMNa45DBnW832utJRyTz0/view?usp=drive_link	Contraloria Municipal	100	SE ENCUENTRA EN PROCESO EL REGLAMENTO DE GOBIERNO Y DE LA ADMINISTRACIÓN PÚBLICA MUNICIPAL DE COATETELCO\n	[{"id": "accion-7-1754418874548", "urlAccion": "https://drive.google.com/file/d/1ld2SbJuS-K0fwyHG9zYRv0-OToW1iR7W/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-27"}, {"id": "action_2", "urlAccion": "https://drive.google.com/file/d/1uNEOBZ0hLI1XUv2i-u8mCnf1zvpOIRxZ/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-24"}]	Completado	2025-08-05 18:35:09.198	2025-08-05 18:47:03.957	\N
18	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Coatetelco	Diagnóstico	https://drive.google.com/file/d/1USbXigOQVA-HqoUD2-KH8PBWFNqv8HZy/view?usp=drive_link	https://drive.google.com/file/d/1gJpWCMviml-C-GrJ6XpsrxxV8u90zVdF/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-8-1754421151471", "urlAccion": "https://drive.google.com/file/d/1Pokjo9Ruur49936q8mjKnET7FnKrNZjs/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-19"}]	Completado	2025-08-05 19:13:07.924	2025-08-05 19:13:07.924	\N
19	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Coatetelco	Diagnóstico	https://drive.google.com/file/d/1sKUzMIbju63wsqXV0cxre_OEfJlxBEgR/view?usp=drive_link	https://drive.google.com/file/d/1rSqnevuSXAu9CJ58kdKlT6s7RzXr7hHN/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 19:29:28.576	2025-08-05 19:29:28.576	\N
20	9. Indicador de Denuncias no pendientes de atención	Coatlán del Río	Diagnóstico	https://saem.gob.mx	https://drive.google.com/file/d/1DuR-MkxdeR3eciSC3iDzMfHRlIYILrWT/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 19:30:17.088	2025-08-05 19:30:17.088	\N
21	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Coatlán del Río	Diagnóstico	https://drive.google.com/file/d/1N9isEQ_wyHsbqDIZsfJr9_zXRVPVhjsF/view?usp=drive_link	https://drive.google.com/file/d/1W5B8ciA7SroYAQ_1uA-Xju_mda-KYzKV/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-9-1754422276015", "urlAccion": "https://drive.google.com/file/d/1uPBkvZaGu_cG_tw-vShxk8U8mskrdZGf/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-27"}]	Completado	2025-08-05 19:48:37.173	2025-08-05 19:48:37.173	\N
22	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Coatlán del Río	Diagnóstico	https://drive.google.com/file/d/17OL3OkIHNjGChnAADsYhRDVI2548WxK_/view?usp=drive_link	https://drive.google.com/file/d/1f40QlnsWCZNovP-xpblssKd70-mTcnRB/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 19:49:31.117	2025-08-05 19:49:31.117	\N
23	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Coatlán del Río	Diagnóstico	https://drive.google.com/file/d/1Kb-HMUNdxEDEjtt0oU7peOShieeEUB6t/view?usp=drive_link	https://drive.google.com/file/d/1DtUPAaxDpqAENmdNI81iErirkzk-D_s3/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 19:50:41.293	2025-08-05 19:50:41.293	\N
24	9. Indicador de Denuncias no pendientes de atención	Cuautla	Diagnóstico	https://saem.gob.mx	https://drive.google.com/file/d/1D_mbYHY8k_A6EXcn05H2jd9jIvGy-Nic/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 20:00:27.89	2025-08-05 20:00:27.89	\N
26	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Cuautla	Diagnóstico	https://drive.google.com/file/d/1wn8_qIwC-Cl6zQnqqL4Y1yVtTZM9Iccs/view?usp=sharing	\N	Contraloria Municipal	0	\N	[{"id": "accion-11-1754424220750", "urlAccion": "https://drive.google.com/file/d/1ukdm9a5mY1_dPSNajjC7iU75Z9Ddmdtj/view?usp=drive_link", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-20"}]	Pendiente	2025-08-05 20:04:05.223	2025-08-05 20:04:05.223	\N
27	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Cuautla	Diagnóstico	https://drive.google.com/file/d/1GozHTyKyPWfsMcFWX08WVOCEmuF9kstk/view?usp=drive_link	https://drive.google.com/file/d/1keygzxc_JK2MzZ-9q-ZhTtYz1U2X_SO6/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 20:07:14.821	2025-08-05 20:07:14.821	\N
28	9. Indicador de Denuncias no pendientes de atención.	Cuernavaca	Diagnóstico	https://saem.gob.mx	https://drive.google.com/file/d/1gEUPXHl9jdo3Oo5R0Pr0dR8drwqNSBEE/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 20:25:30.275	2025-08-05 20:25:30.275	\N
56	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Miacatlán	Diagnóstico	https://drive.google.com/file/d/1ounG1Qu_IXxludKXldtZu-XfVhljTrle/view?usp=drive_link	https://drive.google.com/file/d/1lm_ChACe0_wa2nTQIHtHil3uiUuDDfAN/view?usp=sharing	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:28:23.4	2025-08-05 21:28:23.4	\N
29	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Cuernavaca	Diagnóstico	https://drive.google.com/file/d/1Al98KzSFNA53txfSOeFUOIwWj9kUq62t/view?usp=drive_link	https://drive.google.com/file/d/1arUG_73RZceTuwXQNhwVUCVoE93eZXL7/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 20:26:20.881	2025-08-05 20:26:20.881	\N
30	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Cuernavaca	Diagnóstico	https://drive.google.com/file/d/1fb0fetdc6JwAxXsPfrJAYl-NO0nzUGng/view?usp=drive_link	https://drive.google.com/file/d/11VmNlq0VwX_iPLukjJEhfIz6Qe_Aj0PK/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 20:26:53.609	2025-08-05 20:26:53.609	\N
31	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Cuernavaca	Diagnóstico	https://drive.google.com/file/d/1QAGIMxcy6lAR4O9M5WJ4xIET_5QuNHvv/view?usp=drive_link	https://drive.google.com/file/d/1q6t3Ci-4eolhP0G_FVH4-oqxYkf-amnp/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 20:27:28.039	2025-08-05 20:27:28.039	\N
32	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Emiliano Zapata	Diagnóstico	https://drive.google.com/file/d/1UJMSg71IaDFRWMD-V8cKKni3dmLRBH0O/view?usp=drive_link	https://drive.google.com/file/d/1Rg4Y6Ic_bWTBPnrd0k67M5c-nB1VvfA9/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 20:30:42.962	2025-08-05 20:30:42.962	\N
33	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Emiliano Zapata	Diagnóstico	https://drive.google.com/file/d/1HyZuZDqKNYFG7Gbo6Dq_dpLmL8URhAR3/view?usp=drive_link	https://drive.google.com/file/d/1D5YMYf1yAJ0DvuDKnhofyNycaNC137-d/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-12-1754425875878", "urlAccion": "https://drive.google.com/file/d/1xr23GMQsx82aUJPBusSsVoZp4M46HAhU/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-20"}]	Completado	2025-08-05 20:31:44.419	2025-08-05 20:31:44.419	\N
34	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Emiliano Zapata	Diagnóstico	https://drive.google.com/file/d/1_lachs_K2ZqPhQrOP3u3l3skeUqs2VGX/view?usp=drive_link	https://drive.google.com/file/d/1194r3JMrYu-rRVE47uFzGzZVZYYaysoi/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 20:32:44.032	2025-08-05 20:32:44.032	\N
35	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Hueyapan	Diagnóstico	https://saem.gob.mx	https://drive.google.com/file/d/1nOQqqP4qdYkFu6-4RbBDalAZirWu0tkx/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 20:34:03.712	2025-08-05 20:34:03.712	\N
36	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Hueyapan	Diagnóstico	https://drive.google.com/file/d/1AcumRWPeSRDmqeU23Q2hd_hvIu9JZQmO/view?usp=drive_link	https://drive.google.com/file/d/1wRRkPNrD_UbPEd2YXAswyoRfvlap7rzc/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-14-1754426179459", "urlAccion": "https://drive.google.com/file/d/1564orNSTsXU-mFclro5SszfvWK03bpxf/view?usp=sharing                                                                                                                                                                                                                                                              https://drive.google.com/file/d/1zsJKC8OPojg7SVTtP9Au1i7YqRV9qYpK/view?usp=sharing                                                                                                                                                                                                                                                              https://drive.google.com/file/d/1ruQjPDdK0aM_ph08GbemddZ3O-nZmm1z/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-14"}]	Completado	2025-08-05 20:36:55.966	2025-08-05 20:36:55.966	\N
37	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Hueyapan	Diagnóstico	https://drive.google.com/file/d/16r3AkUWzLMH7KiKK-uHqlZkzZYrZSmus/view?usp=drive_link	https://drive.google.com/file/d/1scAI84l0TujfoCE7qbeWHeZZHMnNlp73/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-15-1754426692451", "urlAccion": "https://drive.google.com/file/d/1wINt1NBo0GmT_D7L8fgZYdoxiS-a-CRW/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-02"}]	Completado	2025-08-05 20:45:30.571	2025-08-05 20:45:30.571	\N
38	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Huitzilac	Diagnóstico	https://drive.google.com/file/d/1bVO_0GjhL1POhTcDY-gkl3O1vQDAUr_J/view?usp=drive_link	https://saem.gob.mx	Contraloria Municipal	100	\N	[{"id": "accion-16-1754426784844", "urlAccion": "https://drive.google.com/file/d/1MHoVeS9pFy2g2JTAp86qDAd_384mulkn/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-20"}]	Completado	2025-08-05 20:47:27.688	2025-08-05 20:47:27.688	\N
39	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Huitzilac	Diagnóstico	https://drive.google.com/file/d/1Tb3hbL24hbH3oFbefcE4V6uSZ_oHh8PJ/view?usp=drive_link	https://drive.google.com/file/d/1KMLaSHelYQLFYGn7dorw4rrr6QPFFELT/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-17-1754426895406", "urlAccion": "https://drive.google.com/file/d/1VQQ_6oHgoetGXHKbXcDwsmQ8ZgkUyHA9/view?usp=sharing                                                                                                                                                                                                                                                                                                                                                                               https://drive.google.com/file/d/1bbMxvnu-pNK2L9fqxCCvdqZmtRZuRaE6/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-19"}]	Completado	2025-08-05 20:48:56.665	2025-08-05 20:48:56.665	\N
40	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Huitzilac	Diagnóstico	https://drive.google.com/file/d/1WWy9_2KpebYkO-7gcAxTfne3MJJvgmpb/view?usp=drive_link	https://drive.google.com/file/d/1fovi-Grd4gaKO41nQCqBFnq_IfJjm7Yc/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 20:52:30.706	2025-08-05 20:52:30.706	\N
98	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Xochitepec	Diagnóstico	https://drive.google.com/file/d/1yITvZtT1rDRM849wr0Drj6oRH-gfB8x4/view?usp=drive_link	https://drive.google.com/file/d/1kDMba87nACKdOQeMaCwg-yQBw_KWoJgk/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:54:44.822	2025-08-05 22:54:44.822	\N
41	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Jantetelco	Diagnóstico	https://drive.google.com/file/d/1xYKLoU4f4tX7XuB5Zny8B9NvsDqn8M_T/view?usp=drive_link	https://drive.google.com/file/d/1YMYNa_Gj5bIjQ1bkd6MNYy3WWfinz3Om/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-18-1754427185536", "urlAccion": "https://drive.google.com/file/d/1uFI1y3Sx8PSUTm8-4hsGq-IYXCkHfqQw/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-27"}]	Completado	2025-08-05 20:53:47.294	2025-08-05 20:53:47.294	\N
42	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Jantetelco	Diagnóstico	https://drive.google.com/file/d/1EsKYnEUlcTPrijNVoLhwYLvPZBJnYklM/view?usp=drive_link	https://drive.google.com/file/d/1kFZBma68nt3I28LNKyhE0p5HTBTSvMZK/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-19-1754427290696", "urlAccion": "https://drive.google.com/file/d/1tmX59Z8kspm3fremnQvE8bg4_KFqy7BH/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-19"}]	Completado	2025-08-05 20:55:18.825	2025-08-05 20:55:18.825	\N
43	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Jiutepec	Diagnóstico	https://drive.google.com/file/d/1gFIxYPauKs0Q4zwBhEZhIUfdviqVOhP8/view?usp=drive_link	https://drive.google.com/file/d/1Ro8tYyh1UQawS3i6l-RmQdHgRHfExs3E/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:03:54.707	2025-08-05 21:03:54.707	\N
44	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Jiutepec	Diagnóstico	https://drive.google.com/file/d/1Cr8UwoYzBIeT1oM9GxXLTK-kdaumj_7X/view?usp=drive_link	https://drive.google.com/file/d/1E6nVTdkbch0HXF_Uuv_xMtRFux2GV-F4/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:04:35.332	2025-08-05 21:04:35.332	\N
45	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Jiutepec	Diagnóstico	https://drive.google.com/file/d/1P7XGL3gOwxL7NWEwLfiY2hr_XdBxLT28/view?usp=drive_link	https://drive.google.com/file/d/1y_yYLTYW2frnIrTZQX_xTfHwfmUlNkEy/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:05:22.402	2025-08-05 21:05:22.402	\N
46	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Jojutla	Diagnóstico	https://drive.google.com/file/d/1C8Y2aLFLWRx5axwwPiHAt2O0rNfrzhQ0/view?usp=drive_link	https://drive.google.com/file/d/1XJuty7W74kLVCd6dWP_w1HcufQJlHqjV/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:06:13.842	2025-08-05 21:06:13.842	\N
47	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Jojutla	Diagnóstico	https://drive.google.com/file/d/1W-M0wJKwH1vaWnlXKtpzRyk0kKGBnnzY/view?usp=drive_link	https://drive.google.com/file/d/12jih5AWp1pWKNcredExIMoSi1q6cNSPX/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:06:51.988	2025-08-05 21:06:51.988	\N
48	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Jonacatepec de Leandro Valle	Diagnóstico	https://drive.google.com/file/d/1EjtIw3oZPFJ_XnyKIceVSYS7wZJO1nge/view?usp=drive_link	https://drive.google.com/file/d/1xMdbCMNQog6uDq0cXamZzUjfPQW2vBXx/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-20-1754428065483", "urlAccion": "https://drive.google.com/file/d/19sxsh3OcB6jA8EXRSZXr24yY3cf-zb86/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-27"}]	Completado	2025-08-05 21:08:31.622	2025-08-05 21:08:31.622	\N
49	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Jonacatepec de Leandro Valle	Diagnóstico	https://drive.google.com/file/d/15-gp17J6b5t3uRn5ikWrxWo46GUgrkfu/view?usp=drive_link	https://saem.gob.mx	Contraloria Municipal	100	\N	[{"id": "accion-21-1754428144967", "urlAccion": "https://drive.google.com/file/d/1_hWPpWubsswKa70doLcHj7AtPs21PqW1/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-20"}]	Completado	2025-08-05 21:11:37.22	2025-08-05 21:11:37.22	\N
50	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Jonacatepec de Leandro Valle	Diagnóstico	https://drive.google.com/file/d/1BGF7DaUcC_fOKee3A9rfCgsOmxJp0f9H/view?usp=drive_link	https://saem.gob.mx	Contraloria Municipal	0	\N	[{"id": "accion-22-1754428406701", "urlAccion": "https://drive.google.com/file/d/1WIF_OcRDG5Szd1t_mhEVA4GiGMiinSOV/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-02"}]	Pendiente	2025-08-05 21:13:56.618	2025-08-05 21:13:56.618	\N
51	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Mazatepec	Diagnóstico	https://drive.google.com/file/d/1x3jH4uxiMXfwMz4nfbA3wY9QyJZAJ4Od/view?usp=drive_link	https://drive.google.com/file/d/1D1eaJH6J0NkM-s90Ux-3Js2u4PZ_2xy8/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-23-1754428500413", "urlAccion": "https://drive.google.com/file/d/1H5JEO6P_GDgyo6fQhpqhx5nRrQhWe-bU/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-27"}]	Completado	2025-08-05 21:15:32.625	2025-08-05 21:15:32.625	\N
52	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Mazatepec	Diagnóstico	https://drive.google.com/file/d/1ko2BCZWR-81lSorAjqjK_QT2c355DwtR/view?usp=drive_link	https://drive.google.com/file/d/1v3sLhsaUOMBwZFDC3chqQXZ3h_fsXY0p/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:16:43.875	2025-08-05 21:16:43.875	\N
53	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Mazatepec	Diagnóstico	https://drive.google.com/file/d/1VfeZ94KfqzKgAlI34KacXfHSr2mpBIZc/view?usp=drive_link	https://saem.gob.mx	Contraloria Municipal	0	\N	[{"id": "accion-24-1754428651357", "urlAccion": "https://drive.google.com/file/d/1oBuVjJD6rhmk8venqsD_3dn81qtimXt9/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-02"}]	Pendiente	2025-08-05 21:18:00.565	2025-08-05 21:18:00.565	\N
54	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Miacatlán	Diagnóstico	https://drive.google.com/file/d/1cBkRXiGk9FXxj14XtTTYx771wC53kn48/view?usp=drive_link	https://drive.google.com/file/d/1URx-ErWBkPJE20NV5bnixEKg0glj4KLZ/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:21:45.147	2025-08-05 21:21:45.147	\N
57	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Ocuituco	Diagnóstico	https://drive.google.com/file/d/14FIcWV0DAr0K8hr0JRT8NTaIMuERRWpQ/view?usp=drive_link 	https://saem.gob.mx	Contraloria Municipal	0	\N	[{"id": "accion-25-1754429327368", "urlAccion": "https://drive.google.com/file/d/1y6zxAJ6iXuPqlMwY19Pd05dp8ir2HO91/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-20"}]	Pendiente	2025-08-05 21:29:53.872	2025-08-05 21:29:53.872	\N
58	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Ocuituco	Diagnóstico	https://drive.google.com/file/d/1tw5JA4i9RqxH_uduyyexepNu_qbwze7w/view?usp=drive_link	https://drive.google.com/file/d/147bz8GDGujtjo-Pq4pDG_v7rdkKuYXTx/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-26-1754429421166", "urlAccion": "https://drive.google.com/file/d/13P3Q_9-PPHlwdWRKHXXQnoYb_Xy4vb3-/view?usp=sharing                                                                                                                                                                                                                                                                                                                                                                                                                           https://drive.google.com/file/d/1fAZpDbkQtBMPrTbELO79LKSbRJScmPGk/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-19"}]	Completado	2025-08-05 21:31:34.167	2025-08-05 21:31:34.167	\N
59	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Ocuituco	Diagnóstico	https://drive.google.com/file/d/1b5wK1paF-2K0nRhvQfuSk70T9YFStSKc/view?usp=drive_link	https://drive.google.com/file/d/1Q-UkkDLgR_kiiAZGqucqliSk48eKeWsc/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:32:38.069	2025-08-05 21:32:38.069	\N
60	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Puente de Ixtla	Diagnóstico	https://saem.gob.mxhttps://drive.google.com/file/d/1fmhBf6qcsuWvzvryg4OdLfGWfbHaXM6l/view?usp=drive_link	https://drive.google.com/file/d/1PvtjTsoSGBXyJybOrOfzXRE6FLIzYOFI/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-28-1754429867673", "urlAccion": "https://drive.google.com/file/d/1twJUaoyjL3WhJHGEtV2UDf4Geqa_srPr/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-27"}]	Completado	2025-08-05 21:38:13.612	2025-08-05 21:38:13.612	\N
61	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Puente de Ixtla	Diagnóstico	https://drive.google.com/file/d/1XLrGFvKNA1yo1F1Q5UWL_azeMgLLns42/view?usp=drive_link	https://drive.google.com/file/d/1-n0Mtk0VHlyv1rgXQzh3t1cmEjMdnNkQ/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-29-1754429950219", "urlAccion": "https://drive.google.com/file/d/198UeS4jstdKHFa9aYb32QyGcjIldIIdO/view?usp=sharing", "completada": false, "descripcion": "", "fechaLimite": "2025-06-19"}]	Completado	2025-08-05 21:39:36.67	2025-08-05 21:39:36.67	\N
62	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Puente de Ixtla	Diagnóstico	https://drive.google.com/file/d/1LNVBzMw9y_G_rTQpME_sceziTZ2KzwWU/view?usp=drive_link	https://drive.google.com/file/d/1oCHfDg6Ot0pgSel3dfNJH1JlZFiiqnHH/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:41:52.321	2025-08-05 21:41:52.321	\N
63	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Temixco	Diagnóstico	https://drive.google.com/file/d/1jcGpD8jCSOhaOrVPy5qZydDi_tuNwuNG/view?usp=drive_link	https://drive.google.com/file/d/1ziCvttBIf9NZcD3GgrI_iDsD4uiN2-q1/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:47:13.461	2025-08-05 21:47:13.461	\N
64	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Temixco	Diagnóstico	https://drive.google.com/file/d/1iyzL95qsjJ5bz4PCO4iM6lUKWL7ijFlJ/view?usp=drive_link	https://drive.google.com/file/d/17KqcGgRJwzykAvaBRw6IhD212vKvUZ2P/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:48:04.476	2025-08-05 21:48:04.476	\N
65	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Temixco	Diagnóstico	https://drive.google.com/file/d/1kzXtWhCovNxXm6X9B0xAEKP1yT5OylFC/view?usp=drive_link	https://drive.google.com/file/d/10Tvf6VzP6Y_iiCPyrme97Vs_7Ku3PERJ/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:49:08.964	2025-08-05 21:49:08.964	\N
66	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Temoac	Diagnóstico	https://drive.google.com/file/d/1ZfMPRd_70UI3OoL2OWCUkqUiOtLNPqXY/view?usp=drive_link 	https://drive.google.com/file/d/1ob5C33-t7MqEMzvaI0_pVXP0hQo0eHf9/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-30-1754430616511", "urlAccion": "https://drive.google.com/file/d/1wASYs8apH2KL4J7dhw1dGD2LZPYi2Mwj/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-27"}]	Completado	2025-08-05 21:51:14.104	2025-08-05 21:51:14.104	\N
67	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Temoac	Diagnóstico	https://drive.google.com/file/d/1AVs6Aanrbab8VN_tKgi2cbL8OazzFCra/view?usp=drive_link	https://drive.google.com/file/d/1Ck9xysQL75tqAArlMfSXL3B5NrZ1f-7o/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:52:27.641	2025-08-05 21:52:27.641	\N
68	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Temoac	Diagnóstico	https://drive.google.com/file/d/18uyK_6AmJl0r0bzx5_drtZb4dgDTMqju/view?usp=drive_link	https://drive.google.com/file/d/1fHZxl_qdzS4jMwnyrMT0SvSQraXXlNVw/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-31-1754430810018", "urlAccion": "https://drive.google.com/file/d/1myJncRuBba1Zu0HkmVhcAmRMzQhguqG8/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-19"}]	Completado	2025-08-05 21:54:02.943	2025-08-05 21:54:02.943	\N
69	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Tepalcingo	Diagnóstico	https://drive.google.com/file/d/1NFy5JiPVFiToDR_o-_9mTf9EpqantnP4/view?usp=drive_link	https://drive.google.com/file/d/1Gyx_84-cOIptMDyqCcvUWiY-o-KgCljJ/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 21:57:09.338	2025-08-05 21:57:09.338	\N
70	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Tepalcingo	Diagnóstico	https://drive.google.com/file/d/1GAoykM7yg2Lb0t3Kv66CwGCe4MoZzaCA/view?usp=drive_link	https://drive.google.com/file/d/1B9KTavGWWL6RXLDlzDRj46ZTKnxGVDYe/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-32-1754431101557", "urlAccion": "https://drive.google.com/file/d/1naLKa1OhpqBUdF6R25Z2OmkLypczzHk3/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-19"}]	Completado	2025-08-05 21:58:54.207	2025-08-05 21:58:54.207	\N
71	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Tepalcingo	Diagnóstico	https://drive.google.com/file/d/1V3qOh-ZnGNSHTtLpjaXtbnpLaXpesGnu/view?usp=drive_link	https://saem.gob.mx	Contraloria Municipal	0	\N	[{"id": "accion-33-1754431381587", "urlAccion": "https://drive.google.com/file/d/1Unmv2SrJL9S_sqjTX0zOJkuQWAX_4LV_/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-02"}]	Pendiente	2025-08-05 22:03:49.376	2025-08-05 22:03:49.376	\N
72	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Tepoztlán	Diagnóstico	https://drive.google.com/file/d/1FQpGXFsAlG1pcc3Dn484E7zSiYdiHjzo/view?usp=drive_link	https://drive.google.com/file/d/1nlb4qwyOjnQnynRIvzgv2gl6nv8Etpov/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-34-1754431955887", "urlAccion": "https://drive.google.com/file/d/1AWZepQqnlUKcomvRlz47SGSLoJJ1cpvN/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-27"}]	Completado	2025-08-05 22:13:06.682	2025-08-05 22:13:06.682	\N
73	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Tepoztlán	Diagnóstico	https://drive.google.com/file/d/179i1Q0zcGDxmJY_Yn2cBGjafRZ8iu0M-/view?usp=drive_link	https://drive.google.com/file/d/14lIsGprqVgtil3nPeBt10sb28F9sawcB/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-35-1754432040222", "urlAccion": "https://drive.google.com/file/d/17JUkVKraZQP_VjEI03V4fVI_zyWJOCBS/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-19"}]	Completado	2025-08-05 22:14:30.197	2025-08-05 22:14:30.197	\N
74	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Tepoztlán	Diagnóstico	https://drive.google.com/file/d/1fTCV85Tc2HeoNB2lgv1upPPpAShXDkGQ/view?usp=drive_link	https://drive.google.com/file/d/1a6LEdEjHuN9JVoy2FRmiU1k1Gh9CLzFd/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:15:03.374	2025-08-05 22:15:03.374	\N
75	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Tetecala	Diagnóstico	https://drive.google.com/file/d/1K2t3afWlm6pb72Lu4zN30MJR9sFhvqRN/view?usp=drive_link 	https://drive.google.com/file/d/1b2Prslkirj1OXHI1lDbV1WceRV1fiknF/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:15:57.895	2025-08-05 22:15:57.895	\N
76	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Tetecala	Diagnóstico	https://drive.google.com/file/d/1iZAKPQPFpRXh3q9I58rUuVoSQrAh-9jY/view?usp=drive_link	https://drive.google.com/file/d/1zRk_8BxOxHfwGoJsaNrI9A8t0jOC-EuR/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-36-1754432236630", "urlAccion": "https://drive.google.com/file/d/16MJvAu67PbbSD8w930gnKoxVLx7HFVQj/view?usp=sharing ", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-19"}]	Completado	2025-08-05 22:18:07.125	2025-08-05 22:18:07.125	\N
77	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Tetecala	Diagnóstico	https://drive.google.com/file/d/1gV1xUsEPnWQCKJcNGA0LOoyoTHTeLwRm/view?usp=drive_link	https://drive.google.com/file/d/1hYLXRgB0aM7oHp4E_hknS6HbB7aOe0nt/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:18:46.456	2025-08-05 22:18:46.456	\N
78	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Tetela del Volcán	Diagnóstico	https://drive.google.com/file/d/1dgcEJ1DokkcXVoordNHD-CMYV3-_yr8N/view?usp=drive_link	https://drive.google.com/file/d/1X2fza6aeRk2KwmolT5iGvtluhxMdtvvr/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:20:02.139	2025-08-05 22:20:02.139	\N
79	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Tetela del Volcán	Diagnóstico	https://drive.google.com/file/d/1JhIm86keWr50uLaGM_2f0QCZ-H50I9tC/view?usp=drive_link	https://drive.google.com/file/d/1udTtMkBnZtwDrgI9H8c9JNnQ_nzvq9Mf/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:20:48.018	2025-08-05 22:20:48.018	\N
80	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Tetela del Volcán	Diagnóstico	https://drive.google.com/file/d/1-Ji-qkAPMtAmKVDRXiJhy5OIsb6zl-qw/view?usp=drive_link	https://drive.google.com/file/d/1yVRaT5j2VKWwv4uaFdBryuRL9Ppq-wfA/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:21:22.209	2025-08-05 22:21:22.209	\N
81	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Tlalnepantla	Diagnóstico	https://drive.google.com/file/d/14H2hQYca1XKFeOsEAJFYimP9tVxvPml1/view?usp=drive_link 	https://saem.gob.mx	Contraloria Municipal	0	\N	[{"id": "accion-37-1754432533143", "urlAccion": "https://drive.google.com/file/d/1jFEPo2VGT0Io-Q38hfBFhU7F__fXn4S_/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-20"}]	Pendiente	2025-08-05 22:25:43.599	2025-08-05 22:25:43.599	\N
82	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Tlalnepantla	Diagnóstico	https://drive.google.com/file/d/1xerELrz37AbOKZwd_JdhYkZtmvdbxGaN/view?usp=drive_link	https://drive.google.com/file/d/1mcpsEsePhqYYozkU6Uh-5UwUp0LW4DYJ/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-38-1754432821184", "urlAccion": "https://drive.google.com/file/d/1gBhdrQTEEJhP6V13D_-6Ku7zKdr7wIpZ/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-20"}]	Completado	2025-08-05 22:27:32.792	2025-08-05 22:27:32.792	\N
83	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Tlalnepantla	Diagnóstico	https://drive.google.com/file/d/1atGexbK5-QpfesJwLbQAqzKA1IdgDxrx/view?usp=drive_link	https://drive.google.com/file/d/1R9TpnmeFO5xiVDEEKcqSjVVMK4h2M83u/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:28:34.304	2025-08-05 22:28:34.304	\N
84	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Tlaltizapán de Zapata	Diagnóstico	https://drive.google.com/file/d/157-T0FgUB7YfsnkIJM3mshiAfsdUEk-n/view?usp=drive_link	https://drive.google.com/file/d/1mVhAoBADiuntdQWQnVIKvUMhUnVNmtEh/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:29:18.943	2025-08-05 22:29:18.943	\N
85	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Tlaltizapán de Zapata	Diagnóstico	https://drive.google.com/file/d/1zy4XLVPm940GvCUshxyrPllzwPqtRD3N/view?usp=drive_link	https://drive.google.com/file/d/1PBqiqj_7I08FdA_ynykNXMqf1ml1uNgr/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:29:58.462	2025-08-05 22:29:58.462	\N
86	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Tlaltizapán de Zapata	Diagnóstico	https://drive.google.com/file/d/1ZKxJz4f1Jlt3ZbMnorit3FJt3jsT_VRa/view?usp=drive_link	https://drive.google.com/file/d/1RJLqdGa3lV5rcb2kINnIJrkb2M4FyY3B/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-41-1754433030891", "urlAccion": "https://drive.google.com/file/d/1EVlAaPe5gpupKF2_Y7yiYVhovDSa2cmK/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-02"}]	Completado	2025-08-05 22:31:07.223	2025-08-05 22:31:07.223	\N
87	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Tlaquiltenango	Diagnóstico	https://drive.google.com/file/d/1K-DkegPW_cPMDpCcc0LyXwpmVxCMxf5p/view?usp=drive_link	https://drive.google.com/file/d/16lJF4nqxefl-jVQi4p4RTZaK8JtN3eyG/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:32:51.178	2025-08-05 22:32:51.178	\N
88	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Tlaquiltenango	Diagnóstico	https://drive.google.com/file/d/1qG14qdnJQVRgqCCI8JyUOEjkN-xaiILA/view?usp=drive_link	https://drive.google.com/file/d/1NiJVMCGGM99PCbeQ8Iu7-FyWQkWIX30x/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-42-1754433222618", "urlAccion": "https://drive.google.com/file/d/1zN1BQketa7kFVZDaDCoR72MfoqAQKwRY/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-19"}]	Completado	2025-08-05 22:34:08.93	2025-08-05 22:34:08.931	\N
89	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Tlaquiltenango	Diagnóstico	https://drive.google.com/file/d/1JPN_WpdtsN1OglY2dkoOdHnnG0VjvpsW/view?usp=drive_link	https://saem.gob.mx	Contraloria Municipal	0	\N	[{"id": "accion-43-1754433829755", "urlAccion": "https://drive.google.com/file/d/1Qz7oEVs3jy-ZfzOgf0NZcC83-s3gasg3/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-02"}]	Pendiente	2025-08-05 22:45:36.064	2025-08-05 22:45:36.064	\N
90	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Totolapan	Diagnóstico	https://drive.google.com/file/d/1AgQI5Q5hK3iJ40O92OPsCC7XFmibB6Hp/view?usp=drive_link	https://saem.gob.mx	Contraloria Municipal	0	\N	[{"id": "accion-44-1754433984426", "urlAccion": "https://drive.google.com/file/d/1BFnfY23JHHkyoOosSAU2TXKeoCpT5Sn3/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-20"}]	Pendiente	2025-08-05 22:46:47.58	2025-08-05 22:46:47.58	\N
91	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Totolapan	Diagnóstico	https://drive.google.com/file/d/1gbgtoG_vvd-OAzP9d8eu5_1-8Iretut1/view?usp=drive_link	https://drive.google.com/file/d/18VAEatn4kKu6TvXrL5fdx9lPhfLMY-VN/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:47:31.083	2025-08-05 22:47:31.083	\N
92	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Totolapan	Diagnóstico	https://drive.google.com/file/d/17wWZnFH-iDjvEIL35tYZB-j83LRmoE5b/view?usp=drive_link	https://drive.google.com/file/d/1mDtSSziz7LVn1K1dxgT4hWfRCogWPwUq/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:48:46.842	2025-08-05 22:48:46.842	\N
93	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Tlayacapan	Diagnóstico	https://drive.google.com/file/d/1B_s6bZmAQUGNIxvFGn1594Hb9As2RJ9h/view?usp=drive_link	https://drive.google.com/file/d/1RDiEXM5QroJ37Cwg389ppsWm7oSoVekl/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:49:21.896	2025-08-05 22:49:21.896	\N
94	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Tlayacapan	Diagnóstico	https://drive.google.com/file/d/1qG14qdnJQVRgqCCI8JyUOEjkN-xaiILA/view?usp=drive_link	https://drive.google.com/file/d/1NiJVMCGGM99PCbeQ8Iu7-FyWQkWIX30x/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-45-1754434190757", "urlAccion": "https://drive.google.com/file/d/1zN1BQketa7kFVZDaDCoR72MfoqAQKwRY/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-19"}]	Completado	2025-08-05 22:50:20.537	2025-08-05 22:50:20.537	\N
95	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Tlayacapan	Diagnóstico	https://drive.google.com/file/d/1ide1RFokKcpWVWHeBvSv_wsJ1dEmuv-Y/view?usp=drive_link	https://drive.google.com/file/d/1yqPnD2_4GUf3k5J_J8E21eIo9_LUN8Rr/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:51:13.799	2025-08-05 22:51:13.799	\N
96	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Xochitepec	Diagnóstico	https://drive.google.com/file/d/1pu1vffWlwEqLoQRDSmVacqmmfBcZuk27/view?usp=drive_link	https://drive.google.com/file/d/1yGKC_lsP0t3ZGuy6025wez_ksOCcXnZX/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-46-1754434347839", "urlAccion": "https://drive.google.com/file/d/16YggWUEspsu5CCg-x30rgZvHxh94zHOK/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-27"}]	Completado	2025-08-05 22:53:01.207	2025-08-05 22:53:01.207	\N
97	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Xochitepec	Diagnóstico	https://drive.google.com/file/d/1dDilK4_IV4HODeoHz522MkKVL_lbS7fz/view?usp=drive_link	https://drive.google.com/file/d/1z8_3qsbjB9e_nnDiP3WZhqTNtDUQl1Em/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-47-1754434429416", "urlAccion": "https://drive.google.com/file/d/18VKjdfs-Hp5ldefBeH1_D5F5zddAjU2d/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-19"}]	Completado	2025-08-05 22:54:10.84	2025-08-05 22:54:10.84	\N
99	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Xoxocotla	Diagnóstico	https://drive.google.com/file/d/14E2n10k87MzffsI5fq7hzbQkg2UiYjJ0/view?usp=drive_link	https://drive.google.com/file/d/1Y_5PrajS9usdLynjJP2p6nEVHXw_42wG/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 22:55:38.059	2025-08-05 22:55:38.059	\N
100	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Xoxocotla	Diagnóstico	https://drive.google.com/file/d/1I7hoJLWiWK-jPoCaxXXROzgh93iWtQcU/view?usp=drive_link	https://drive.google.com/file/d/1aqoXASnin1_n-LxGXY-iNJIZGw0n5wLM/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-49-1754434570334", "urlAccion": "https://drive.google.com/file/d/1zSGvvOHEMtHa4yQN0eBif7BCCaML5qAu/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-19"}]	Completado	2025-08-05 22:56:33.709	2025-08-05 22:56:33.709	\N
101	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Xoxocotla	Diagnóstico	https://drive.google.com/file/d/1TvYj5PWxR2rCkNedDgzoNjSy4NV8fd0a/view?usp=drive_link	https://drive.google.com/file/d/1UXVnPPFgKPsYyiP46Z7NKJLR5Hq09Fmy/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-50-1754434641242", "urlAccion": "https://drive.google.com/file/d/1EagsgE6HFLVtjP9ac1LEKbYs4yZ7C_mL/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-02"}]	Completado	2025-08-05 22:57:52.797	2025-08-05 22:57:52.797	\N
102	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Yautepec	Diagnóstico	https://drive.google.com/file/d/135fEh3_gBLKowyr8T0XjVCJES0yVf9P4/view?usp=drive_link	https://drive.google.com/file/d/1akQwiGBlEHNg4L8mft_wuHIAwNLlhUBX/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 23:01:13.685	2025-08-05 23:01:13.685	\N
103	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Yautepec	Diagnóstico	https://drive.google.com/file/d/15lwdu0_OvtvRGzJMchGyjWnFZjATRju-/view?usp=drive_link	https://drive.google.com/file/d/15b2EOZuuhZjWkkMg6ZgOuH9CtbmaurHW/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 23:01:51.362	2025-08-05 23:01:51.362	\N
104	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Yautepec	Diagnóstico	https://drive.google.com/file/d/1w09pkCoYFisz_wBdvJ6y5g19MTFd4oQu/view?usp=drive_link	https://drive.google.com/file/d/1UsKnFsphwyW9MxIacRExko3PaunIEBOi/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 23:02:26.493	2025-08-05 23:02:26.493	\N
105	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Yecapixtla	Diagnóstico	https://drive.google.com/file/d/1AmdX65emgzpFFhpmF4Zu0M6IQMWqvNMp/view?usp=drive_link	https://drive.google.com/file/d/1rnkCAoo66Jc0xGwXqqCjpCwynwKiwpYC/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-51-1754434996515", "urlAccion": "https://drive.google.com/file/d/1vrrScfKXQp0l7ZcCnvyP3cR2_OzJvI9g/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-27"}]	Completado	2025-08-05 23:03:41.55	2025-08-05 23:03:41.55	\N
106	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Yecapixtla	Diagnóstico	https://drive.google.com/file/d/1G8WvLHEyjW6kQR4lWke94iJxSDVcJwXZ/view?usp=sharing	https://saem.gob.mx	Contraloria Municipal	0	\N	[{"id": "accion-52-1754435059684", "urlAccion": "https://drive.google.com/file/d/1fibmraSPKAUXb0oOMRX92URawoPdLkZ3/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-20"}]	Pendiente	2025-08-05 23:04:45.833	2025-08-05 23:04:45.833	\N
107	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Yecapixtla	Diagnóstico	https://drive.google.com/file/d/1zCmUAIZS7OC2gZOa5vjMy4vFbQOqeKGX/view?usp=drive_link	https://saem.gob.mx	Contraloria Municipal	0	\N	[{"id": "accion-53-1754435111147", "urlAccion": "https://drive.google.com/file/d/1QgQE9S19RYhVFW_wF-BtE4R_hFy-TCWi/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-02"}]	Pendiente	2025-08-05 23:05:37.991	2025-08-05 23:05:37.991	\N
108	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Zacatepec	Diagnóstico	https://drive.google.com/file/d/1arWBPLPfD4G3bhtdxMtHl3lHHF7_QFTi/view?usp=drive_link	https://drive.google.com/file/d/1YBy4RSHqo4ZfKRUL5R79C-YwM4nYt7sy/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-54-1754435203055", "urlAccion": "https://drive.google.com/file/d/1c0Zi2TdpUzlTPuXrOoVoa2Qn9QTTSLzC/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-27"}]	Completado	2025-08-05 23:07:06.991	2025-08-05 23:07:06.991	\N
109	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Zacatepec	Diagnóstico	https://drive.google.com/file/d/1h0GQOis7PLQirdRukB0ElvXb1twPxUWO/view?usp=drive_link	https://drive.google.com/file/d/18DHm-9MrFwjJEwcbXYTbE23kr31QWtld/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 23:07:50.613	2025-08-05 23:07:50.613	\N
110	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Zacatepec	Diagnóstico	https://drive.google.com/file/d/1B9hLg2ydoV2G77od4SMJ_P2rJawvvOZ2/view?usp=drive_link	https://drive.google.com/file/d/1x1esYZUunBgNeSVph0hKh5Or_6uBPSRI/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 23:08:27.343	2025-08-05 23:08:27.343	\N
111	13. Diagnóstico en Materia de entes públicos que han implementado las bases generales para la determinación de necesidades de personal y de evaluación de perfiles y capacidades, como parte de los procesos de reclutamiento y selección de personal.	Zacualpan de Amilpas	Diagnóstico	https://drive.google.com/file/d/1rQPLg_kGqkIu0cQBM0MGi9b6199hVGeW/view?usp=drive_link	https://drive.google.com/file/d/1o-bawZa94gKGyUdfdIMgXcBqb0wTMRkW/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-55-1754435344837", "urlAccion": "https://drive.google.com/file/d/1YrZodu8BToZXLjw9D745D_SrqWALEYFO/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-05-27"}]	Completado	2025-08-05 23:09:25.024	2025-08-05 23:09:25.024	\N
112	20. Diagnóstico relativo al Grado de participación ciudadana y uso de información pública, transparencia y protección de datos personales.	Zacualpan de Amilpas	Diagnóstico	https://drive.google.com/file/d/1jsaYutZqmBJQqySs2Dgx-ONXXmY3e9SZ/view?usp=drive_link	https://drive.google.com/file/d/1wV8xLROEsaarEUiVgR8SFRKj721XLNgj/view?usp=drive_link	Contraloria Municipal	100	\N	[{"id": "accion-56-1754435390237", "urlAccion": "https://drive.google.com/file/d/1HHX8IRXIT06wAGwzhsIuPw8DoThTAS5O/view?usp=sharing                                                             https://drive.google.com/file/d/14L9Ksb-kdW7NiZXm1sra-qVXzTZ60Jgf/view?usp=sharing", "completada": false, "descripcion": "Invitación", "fechaLimite": "2025-06-19"}]	Completado	2025-08-05 23:10:11.665	2025-08-05 23:10:11.665	\N
113	26. Diagnóstico relativo al Fortalecimiento de Procesos de Compras Públicas (FPCP).	Zacualpan de Amilpas	Diagnóstico	https://drive.google.com/file/d/1spySOYLlpnOYQH74FjCnwtR7u6cYfq6u/view?usp=drive_link	https://drive.google.com/file/d/1jnX5tOkyZ5dbUBqOTUajsfUH8Eur-KcO/view?usp=drive_link	Contraloria Municipal	100	\N	[]	Completado	2025-08-05 23:10:46.178	2025-08-05 23:10:46.178	\N
\.


--
-- TOC entry 3415 (class 0 OID 16546)
-- Dependencies: 214
-- Data for Name: directorio_oic; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directorio_oic (id, "oicNombre", puesto, nombre, "correoElectronico", telefono, direccion, entidad, "createdAt", "updatedAt") FROM stdin;
2	MUNICIPIO DE ATLATLAHUCAN	CONTRALOR	IVAN GONZALEZ PERALTA	contraloriaatlatlahucan2025@gmail.com	7353514016	\N	{"nombre": "Morelos"}	2025-07-09 19:24:56.689	2025-07-09 19:24:56.688
3	MUNICIPIO DE AXOCHIAPAN	CONTRALORA	MARIANA PLIEGO MARTÍNEZ	ayuntamientoaxo2527@gmail.com	7693510024	\N	{"nombre": "Morelos"}	2025-07-09 19:36:55.646	2025-07-09 19:36:55.644
4	MUNICIPIO DE AYALA	CONTRALOR	MARIO FILOMENO RÍOS	marfiri@hotmail.com	7351402087	\N	{"nombre": "Morelos"}	2025-07-09 19:38:48.531	2025-07-09 19:38:48.53
5	MUNICIPIO DE COATETELCO	CONTRALOR	ROBERTO DIEGO GARCÍA	robertodiegogarcia@gmail.com	7774493602	No Reelección, Edificio Bella Vista, Despacho 115, Centro, 62000 Cuernavaca, Morelos	{"nombre": "Morelos"}	2025-07-09 19:40:10.757	2025-07-09 19:40:10.681
6	MUNICIPIO DE COATLÁN DEL RÍO	CONTRALOR	SALVADOR ALCARAZ FLORES	contraloriacoatlandelrio25.27@gmail.com	7341315206	\N	{"nombre": "Morelos"}	2025-07-09 19:53:09.432	2025-07-09 19:53:09.431
7	MUNICIPIO DE CUAUTLA	CONTRALORA	BRISS MAHALALELH ROJAS DE LA CRUZ	contraloria.cuautla.morelos@gmail.com	7351690779	\N	{"nombre": "Morelos"}	2025-07-09 19:56:38.827	2025-07-09 19:56:38.825
8	MUNICIPIO DE CUERNAVACA	CONTRALORA	TANIA BERENICE ULLOA ZAMORA	tania.ulloa@cuernavaca.gob.mx	7772084955	\N	{"nombre": "Morelos"}	2025-07-09 20:10:20.685	2025-07-09 20:10:20.611
9	MUNICIPIO DE EMILIANO ZAPATA	CONTRALOR	AMADOR ESQUIVEL CABELLO	amadoresquivelcabello040@gmail.com	7771282867	\N	{"nombre": "Morelos"}	2025-07-09 20:13:21.11	2025-07-09 20:13:21.109
10	MUNICIPIO DE HUEYAPAN	CONTRALORA	FLOR IRENE TORRES REYES	contraloriahueyapan@outlook.com	7352488850	\N	{"nombre": "Morelos"}	2025-07-09 20:14:17.81	2025-07-09 20:14:17.809
11	MUNICIPIO DE HUITZILAC	CONTRALOR	MAURILIO CANO VEGA	maucano1990@gmail.com	7775045798	\N	{"nombre": "Morelos"}	2025-07-09 20:14:58.996	2025-07-09 20:14:58.995
12	MUNICIPIO DE JANTETELCO	CONTRALORA	OLIVIA DE LA TORRE AGUILAR	contraloriazacualpan@outlook.com	7351093612	\N	{"nombre": "Morelos"}	2025-07-09 20:15:39.806	2025-07-09 20:15:39.738
13	MUNICIPIO DE JIUTEPEC	CONTRALOR	ENRIQUE BENITEZ GARCÍA	contraloria2019jojutla@gmail.com	7772058410	\N	{"nombre": "Morelos"}	2025-07-09 20:17:36.181	2025-07-09 20:17:36.18
14	MUNICIPIO DE JOJUTLA	CONTRALOR	ENRIQUE BENITEZ GARCÍA	contraloria2019jojutla@gmail.com	7341032689	\N	{"nombre": "Morelos"}	2025-07-09 20:20:20.378	2025-07-09 20:20:20.306
15	MUNICIPIO DE JONACATEPEC	CONTRALOR	NESTOR MORALES PALMA	mocla10@hotmail.com	7353279328	\N	{"nombre": "Morelos"}	2025-07-09 20:21:02.092	2025-07-09 20:21:02.091
16	MUNICIPIO DE MAZATEPEC	CONTRALOR	URIEL GONZÁLEZ SOTELO	mazatepec2527.contraloria@gmail.com	7771057144	\N	{"nombre": "Morelos"}	2025-07-09 20:21:50.415	2025-07-09 20:21:50.413
17	MUNICIPIO DE MIACATLÁN	CONTRALOR	LUIS MANUEL VEGA LABRA	contraloriamiacatlan2527@gmail.com	7771629851	\N	{"nombre": "Morelos"}	2025-07-09 20:22:30.207	2025-07-09 20:22:30.206
18	MUNICIPIO DE OCUITUCO	CONTRALOR	EBER FONSECA YAÑEZ	contraloria@ocuituco.gob.mx	7313570161	\N	{"nombre": "Morelos"}	2025-07-09 20:23:17.909	2025-07-09 20:23:17.908
19	MUNICIPIO DE PUENTE DE IXTLA	CONTRALOR	RENÉ ALMANZA RODRÍGUEZ	contraloria@municipiopuentedeixtla.gob.mx	7775629495	\N	{"nombre": "Morelos"}	2025-07-09 20:24:07.863	2025-07-09 20:24:07.862
20	MUNICIPIO DE TEMIXCO	CONTRALOR	PATRICIA PEÑA JAIME	contraloria-municipal@temixco.gob.mx	7771251979	\N	{"nombre": "Morelos"}	2025-07-09 20:24:49.018	2025-07-09 20:24:49.017
21	MUNICIPIO DE TEMOAC	CONTRALOR	ROSAURA DE LEÓN FLORES	deleonrosy2909@gmail.com	7351004237	\N	{"nombre": "Morelos"}	2025-07-09 20:26:19.832	2025-07-09 20:26:19.76
22	MUNICIPIO DE TEPALCINGO	CONTRALOR	GABINO VALENCIA AGUILAR	tepalcingocontraloria@gmail.com	7352009717	\N	{"nombre": "Morelos"}	2025-07-09 20:31:08.475	2025-07-09 20:31:08.473
23	MUNICIPIO DE TEPOZTLÁN	CONTRALOR	JUAN CARLOS SÁNCHEZ ROMERO	carlos_ttkla@hotmail.com	7771092853	\N	{"nombre": "Morelos"}	2025-07-09 20:34:05.657	2025-07-09 20:34:05.656
24	MUNICIPIO DE TETECALA	CONTRALORA	ANGÉLICA SOLANO GUTIÉRREZ	angers_solgut@hotmail.com	7772207848	\N	{"nombre": "Morelos"}	2025-07-09 20:45:35.718	2025-07-09 20:45:35.646
25	MUNICIPIO DE TETELA DEL VOLCÁN	CONTRALOR	YOAN CARLOS JIMÉNEZ BARRETO	contraloria.teteladv.2025.2027@gmail.com	7313570003	\N	{"nombre": "Morelos"}	2025-07-09 20:46:27.135	2025-07-09 20:46:27.134
26	MUNICIPIO DE TLALNEPANTLA	CONTRALOR	ANDY ALDAIR LIMA MEJÍA	contraloriatlalnepantla25.27@gmail.com	7352440692	\N	{"nombre": "Morelos"}	2025-07-09 21:04:29.283	2025-07-09 21:04:29.281
27	MUNICIPIO DE TLALTIZAPÁN	CONTRALORA	MIRIAM GUERRERO PÉREZ	contraloria@tlaltizapandezapata.gob.mx	7772592601	\N	{"nombre": "Morelos"}	2025-07-09 21:05:37.814	2025-07-09 21:05:37.741
28	MUNICIPIO DE TLAQUILTENANGO	CONTRALOR	ALBERTO RAMÍREZ RODRÍGUEZ	contratlaqui2025@gmail.com	7772341215	\N	{"nombre": "Morelos"}	2025-07-09 21:06:25.739	2025-07-09 21:06:25.738
29	MUNICIPIO DE TLAYACAPAN	CONTRALOR	JOSE GEISMAR DE LA ROSA PEDRAZA	contraloria.tlayacapan2025@gmail.com	7354165647	\N	{"nombre": "Morelos"}	2025-07-09 21:07:04.863	2025-07-09 21:07:04.862
30	MUNICIPIO DE TOTOLAPAN	CONTRALORA	JANETH MEDINA BARRERA	totolapancontraloria@gmail.com	5549468060	\N	{"nombre": "Morelos"}	2025-07-09 21:09:58.672	2025-07-09 21:09:58.67
31	MUNICIPIO DE XOCHITEPEC	CONTRALOR	GERARDO SÁNCHEZ BAHENA	contraloriamunicipal@xochitepec.gob.mx	7773614109	\N	{"nombre": "Morelos"}	2025-07-09 21:10:41.71	2025-07-09 21:10:41.709
32	MUNICIPIO DE XOXOCOTLA	CONTRALORA	TANIA GIOVANNA CRUZ GÓMEZ	giovannatcg20@gmail.com	7772192863	\N	{"nombre": "Morelos"}	2025-07-09 21:11:20.736	2025-07-09 21:11:20.735
33	MUNICIPIO DE YAUTEPEC	CONTRALORA	MARLEN YAHAIRA ROMÁN YÁÑEZ	contraloriamunicipalyautepec@gmail.com	7353942393	\N	{"nombre": "Morelos"}	2025-07-09 21:12:56.942	2025-07-09 21:12:56.94
34	MUNICIPIO DE YECAPIXTLA	CONTRALORA	KARINA FABIOLA RENDÓN SÁNCHEZ	contraloria@yecapixtla.gob.mx	7352588465	\N	{"nombre": "Morelos"}	2025-07-09 21:21:34.98	2025-07-09 21:21:34.909
35	MUNICIPIO DE ZACATEPEC	CONTRALOR	SALVADOR DELGADO GOYTIA	contraloria.municipal@ayuntamientodezacatepec.gob.mx	7343479199	\N	{"nombre": "Morelos"}	2025-07-09 21:23:08.139	2025-07-09 21:23:08.138
36	MUNICIPIO DE ZACUALPAN DE AMILPAS	CONTRALORA	JUDITH YAJAIRA MILLÁN FUENTES	j.yajaira_2104@hotmail.com	7313574005	\N	{"nombre": "Morelos"}	2025-07-09 21:23:38.595	2025-07-09 21:23:38.594
\.


--
-- TOC entry 3417 (class 0 OID 16556)
-- Dependencies: 216
-- Data for Name: directorio_oic_entes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directorio_oic_entes (id, "directorioOICId", "entePublicoId") FROM stdin;
2	2	71
3	3	72
4	4	73
5	5	74
6	6	75
7	7	76
8	8	77
9	9	78
10	10	79
11	11	80
12	12	81
13	13	82
14	14	83
15	15	84
16	16	85
17	17	86
18	18	87
19	19	88
20	20	89
21	21	90
22	22	91
23	23	92
24	24	93
25	25	94
26	26	95
27	27	96
28	28	97
29	29	99
30	30	100
31	31	101
32	32	102
33	33	103
34	34	104
35	35	105
36	36	106
\.


--
-- TOC entry 3419 (class 0 OID 16563)
-- Dependencies: 218
-- Data for Name: entes_publicos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.entes_publicos (id, nombre, "ambitoGobierno", "poderGobierno", "controlOIC", "controlTribunal", sistema1, sistema2, sistema3, sistema6, entidad, municipio, "createdAt", "updatedAt") FROM stdin;
1	AEROPUERTO DE CUERNAVACA S.A. DE C.V.	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-04 21:05:54.333	2025-07-04 21:05:54.333
4	CENTRO DE CONCILIACIÓN LABORAL DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:28:33.3	2025-07-07 15:28:33.3
5	CENTRO ESTATAL DE PREVENCIÓN SOCIAL DE LA VIOLENCIA Y LA DELINCUENCIA CON PARTICIPACIÓN CIUDADANA	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:28:48.709	2025-07-07 15:28:48.709
6	CENTRO MORELENSE DE LAS ARTES	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:29:02.298	2025-07-07 15:29:02.298
7	COLEGIO DE BACHILLERES DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:29:22.214	2025-07-07 15:29:22.214
8	COLEGIO DE ESTUDIOS CIENTÍFICOS Y TECNOLÓGICOS DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:31:49.765	2025-07-07 15:31:49.765
9	COLEGIO NACIONAL DE EDUCACION PROFESIONAL TECNICA DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:32:03.972	2025-07-07 15:32:03.972
10	COMISION DE BÚSQUEDA DE PERSONAS DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:33:02.006	2025-07-07 15:33:02.006
11	COMISION DE DERECHOS HUMANOS DEL ESTADO DE MORELOS	Estatal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:33:27.875	2025-07-07 15:33:27.875
12	COMISION DE DERECHOS HUMANOS DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:33:44.585	2025-07-07 15:33:44.585
13	COMISION ESTATAL DE EVALUACIÓN DEL DESARROLLO SOCIAL	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:35:24.565	2025-07-07 15:35:24.565
14	COMISIÓN EJECUTIVA DE ATENCIÓN Y REPARACIÓN A VÍCTIMAS DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:35:41.191	2025-07-07 15:35:41.191
15	COMISIÓN ESTATAL DE ARBITRAJE MÉDICO DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:36:03.748	2025-07-07 15:36:03.748
16	COMISIÓN ESTATAL DE BIODIVERSIDAD	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:36:20.254	2025-07-07 15:36:20.254
17	COMISIÓN ESTATAL DE MEJORA REGULATORIA	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:36:33.438	2025-07-07 15:36:33.438
18	COMISIÓN ESTATAL DE RESERVAS TERRITORIALES	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:36:54.432	2025-07-07 15:36:54.432
19	COMISIÓN ESTATAL DEL AGUA	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:37:07.223	2025-07-07 15:37:07.223
20	CONGRESO DEL ESTADO DE MORELOS	Estatal	Legislativo	f	f	t	f	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:37:30.444	2025-07-07 15:37:30.444
21	CONSEJERÍA JURÍDICA	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:45:31.014	2025-07-07 15:45:31.014
22	CONSEJO DE CIENCIA Y TECNOLOGÍA DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:45:44.724	2025-07-07 15:45:44.724
23	COORDINACIÓN ESTATAL DE PROTECCIÓN CIVIL DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:46:09.275	2025-07-07 15:46:09.275
24	COORDINACIÓN ESTATAL DEL SUBSISTEMA DE PREPARATORIA ABIERTA	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:46:25.521	2025-07-07 15:46:25.521
25	COORDINACIÓN GENERAL DE MOVILIDAD Y TRANSPORTE	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:46:45.061	2025-07-07 15:46:45.061
26	EL COLEGIO DE MORELOS	Estatal	Autónomo	f	f	t	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:47:05.979	2025-07-07 15:47:05.979
27	EL COLEGIO DE MORELOS	Estatal	Autónomo	t	f	f	f	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:48:25.521	2025-07-07 15:48:25.521
28	ENTIDAD SUPERIOR DE AUDITORÍA Y FISCALIZACIÓN	Estatal	Legislativo	f	f	t	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:49:01.854	2025-07-07 15:49:01.854
30	ENTIDAD SUPERIOR DE AUDITORÍA Y FISCALIZACIÓN	Estatal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:49:48.162	2025-07-07 15:49:48.162
31	FIDEICOMISO BALNEARIO AGUA HEDIONDA	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:50:57.486	2025-07-07 15:50:57.486
32	FIDEICOMISO CENTRO CULTURAL TEOPANZOLCO	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:51:16.278	2025-07-07 15:51:16.278
33	FIDEICOMISO CENTRO DE CONGRESOS Y CONVENCIONES MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:51:29.974	2025-07-07 15:51:29.974
34	FIDEICOMISO DEL FONDO DE COMPETITIVIDAD Y PROMOCIÓN DEL EMPLEO	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:51:43.879	2025-07-07 15:51:43.879
35	FIDEICOMISO FONDO DESARROLLO EMPRESARIAL Y PROMOCIÓN DE LA INVERSIÓN	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:51:57.228	2025-07-07 15:51:57.228
36	FIDEICOMISO IMPULSO FINANCIERO AL CAMPO MORELENSE	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:52:14.671	2025-07-07 15:52:14.671
37	FIDEICOMISO LAGO DE TEQUESQUITENGO	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:52:45.05	2025-07-07 15:52:45.05
38	FIDEICOMISO MUSEO MORELENSE DE ARTE CONTEMPORANEO JUAN SORIANO	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:52:56.743	2025-07-07 15:52:56.743
39	FIDEICOMISO PARQUE CIENTÍFICO Y TECNOLÓGICO MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:54:03.332	2025-07-07 15:54:03.332
40	FIDEICOMISO TURISMO MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:54:20.432	2025-07-07 15:54:20.432
41	FISCALÍA GENERAL DEL ESTADO DE MORELOS	Estatal	Autónomo	f	f	t	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:54:40.617	2025-07-07 15:54:40.617
42	FISCALÍA GENERAL DEL ESTADO DE MORELOS	Estatal	Autónomo	t	f	f	f	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:55:04.433	2025-07-07 15:55:04.433
43	FONDO DE FOMENTO AGROPECUARIO DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:55:54.427	2025-07-07 15:55:54.427
44	FONDO ESTATAL PARA LA ADMINISTRACIÓN Y OPERACIÓN DEL RECINTO DEPORTIVO AGUSTÍN CORUCO DÍAZ	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:56:53.921	2025-07-07 15:56:53.921
45	FONDO ESTATAL PARA LA PROMOCIÓN Y DESARROLLO DE EVENTOS VINCULADOS CON LA CULTURA Y EL TURISMO	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:57:08.732	2025-07-07 15:57:08.732
46	HOSPITAL DEL NIÑO MORELENSE	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:57:23.535	2025-07-07 15:57:23.535
47	INSTITUTO DE CAPACITACIÓN PARA EL TRABAJO DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:57:35.606	2025-07-07 15:57:35.606
48	INSTITUTO DE CRÉDITO PARA LOS TRABAJADORES AL SERVICIO DEL GOBIERNO DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:57:50.275	2025-07-07 15:57:50.275
49	INSTITUTO DE DESARROLLO Y FORTALECIMIENTO MUNICIPAL DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:58:09.638	2025-07-07 15:58:09.638
50	INSTITUTO DE EDUCACIÓN BÁSICA DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:59:06.982	2025-07-07 15:59:06.982
51	INSTITUTO DE LA DEFENSORÍA PÚBLICA DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:59:20.264	2025-07-07 15:59:20.264
52	INSTITUTO DE LA MUJER PARA EL ESTADO DE MORELOS	Estatal	Autónomo	f	f	f	f	f	f	{"nombre": "Morelos"}	\N	2025-07-07 15:59:35.809	2025-07-07 15:59:35.809
53	INSTITUTO DE LA MUJER PARA EL ESTADO DE MORELOS	Estatal	Autónomo	t	f	f	f	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:00:07.948	2025-07-07 16:00:07.948
54	INSTITUTO DE LOS PUEBLOS Y COMUNIDADES INDÍGENAS Y AFROMEXICANAS DE MORELOS	Estatal	Ejecutivo	f	f	f	f	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:00:23.378	2025-07-07 16:00:23.378
55	INSTITUTO DE SERVICIOS REGISTRALES Y CATASTRALES DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:00:42.274	2025-07-07 16:00:42.274
56	INSTITUTO DEL DEPORTE Y CULTURA FÍSICA DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:03:51.085	2025-07-07 16:03:51.085
57	INSTITUTO ESTATAL DE DOCUMENTACIÓN DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:04:13.558	2025-07-07 16:04:13.558
58	INSTITUTO ESTATAL DE EDUCACIÓN PARA ADULTOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:04:26.782	2025-07-07 16:04:26.782
59	INSTITUTO ESTATAL DE INFRAESTRUCTURA EDUCATIVA	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:04:47.57	2025-07-07 16:04:47.57
60	INSTITUTO MORELENSE DE INFORMACIÓN PÚBLICA Y ESTADÍSTICA	Estatal	Autónomo	f	f	t	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:05:16.977	2025-07-07 16:05:16.977
61	INSTITUTO MORELENSE DE INFORMACIÓN PÚBLICA Y ESTADÍSTICA	Estatal	Autónomo	t	f	f	f	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:05:32.95	2025-07-07 16:05:32.95
63	INSTITUTO MORELENSE DE LAS PERSONAS ADOLESCENTES Y JÓVENES	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:08:54.762	2025-07-07 16:08:54.762
64	INSTITUTO MORELENSE DE PROCESOS ELECTORALES Y PARTICIPACIÓN CIUDADANA	Estatal	Autónomo	t	f	f	f	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:09:16.678	2025-07-07 16:09:16.678
65	INSTITUTO MORELENSE DE PROCESOS ELECTORALES Y PARTICIPACIÓN CIUDADANA	Estatal	Autónomo	f	f	t	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:09:33.191	2025-07-07 16:09:33.191
66	INSTITUTO MORELENSE DE RADIO Y TELEVISIÓN	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:10:54.324	2025-07-07 16:10:54.324
67	INSTITUTO MORELENSE PARA EL FINANCIAMIENTO DEL SECTOR PRODUCTIVO	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:11:06.231	2025-07-07 16:11:06.231
68	INSTITUTO PROVETERANOS DE LA REVOLUCIÓN DEL SUR	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:11:20.066	2025-07-07 16:11:20.066
69	JUNTA LOCAL DE CONCILIACIÓN Y ARBITRAJE DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-07 16:15:20.876	2025-07-07 16:15:20.876
70	MUNICIPIO DE AMACUZAC	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Amacuzac	2025-07-07 16:16:28.362	2025-07-07 16:16:28.362
71	MUNICIPIO DE ATLATLAHUCAN	Municipal	Ejecutivo	f	f	t	f	f	f	{"nombre": "Morelos"}	Atlatlahucan	2025-07-07 16:16:57.026	2025-07-07 16:16:57.026
72	MUNICIPIO DE AXOCHIAPAN	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Axochiapan	2025-07-07 16:17:20.178	2025-07-07 16:17:20.178
73	MUNICIPIO DE AYALA	Municipal	Ejecutivo	f	f	f	f	f	f	{"nombre": "Morelos"}	Ayala	2025-07-07 16:21:51.615	2025-07-07 16:21:51.615
74	MUNICIPIO DE COATETELCO	Municipal	Ejecutivo	f	f	t	f	f	f	{"nombre": "Morelos"}	Coatetelco	2025-07-07 16:22:10.122	2025-07-07 16:22:10.122
75	MUNICIPIO DE COATLÁN DEL RÍO	Municipal	Ejecutivo	f	f	t	f	f	f	{"nombre": "Morelos"}	Coatlán del Río	2025-07-07 16:22:47.395	2025-07-07 16:22:47.395
76	MUNICIPIO DE CUAUTLA	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Cuautla	2025-07-07 16:23:08.9	2025-07-07 16:23:08.9
77	MUNICIPIO DE CUERNAVACA	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Cuernavaca	2025-07-07 16:23:34.692	2025-07-07 16:23:34.692
78	MUNICIPIO DE EMILIANO ZAPATA	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Emiliano Zapata	2025-07-07 16:24:10.027	2025-07-07 16:24:10.027
79	MUNICIPIO DE HUEYAPAN	Municipal	Ejecutivo	f	f	t	f	f	f	{"nombre": "Morelos"}	Hueyapan	2025-07-07 16:24:43.714	2025-07-07 16:24:43.714
80	MUNICIPIO DE HUITZILAC	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Huitzilac	2025-07-07 16:26:07.327	2025-07-07 16:26:07.327
81	MUNICIPIO DE JANTETELCO	Municipal	Ejecutivo	f	f	f	f	f	f	{"nombre": "Morelos"}	Jantetelco	2025-07-07 16:26:51.803	2025-07-07 16:26:51.803
82	MUNICIPIO DE JIUTEPEC	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Jiutepec	2025-07-07 16:27:10.192	2025-07-07 16:27:10.192
83	MUNICIPIO DE JOJUTLA	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Jojutla	2025-07-07 16:27:40.708	2025-07-07 16:27:40.708
84	MUNICIPIO DE JONACATEPEC	Municipal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	Jonacatepec de Leandro Valle	2025-07-09 17:07:21.501	2025-07-09 17:07:21.501
85	MUNICIPIO DE MAZATEPEC	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Mazatepec	2025-07-09 17:07:41.608	2025-07-09 17:07:41.608
86	MUNICIPIO DE MIACATLÁN	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Miacatlán	2025-07-09 17:08:03.307	2025-07-09 17:08:03.307
87	MUNICIPIO DE OCUITUCO	Municipal	Ejecutivo	f	f	t	f	f	f	{"nombre": "Morelos"}	Ocuituco	2025-07-09 17:08:31.433	2025-07-09 17:08:31.433
88	MUNICIPIO DE PUENTE DE IXTLA	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Puente de Ixtla	2025-07-09 17:09:07.633	2025-07-09 17:09:07.633
89	MUNICIPIO DE TEMIXCO	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Temixco	2025-07-09 17:09:32.895	2025-07-09 17:09:32.895
90	MUNICIPIO DE TEMOAC	Municipal	Ejecutivo	f	f	t	f	f	f	{"nombre": "Morelos"}	Temoac	2025-07-09 17:09:56.48	2025-07-09 17:09:56.48
91	MUNICIPIO DE TEPALCINGO	Municipal	Ejecutivo	f	f	f	f	f	f	{"nombre": "Morelos"}	Tepalcingo	2025-07-09 17:10:18.987	2025-07-09 17:10:18.987
92	MUNICIPIO DE TEPOZTLÁN	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Tepoztlán	2025-07-09 17:10:47.217	2025-07-09 17:10:47.217
93	MUNICIPIO DE TETECALA	Municipal	Ejecutivo	f	f	f	f	f	f	{"nombre": "Morelos"}	Tetecala	2025-07-09 17:11:17.575	2025-07-09 17:11:17.575
94	MUNICIPIO DE TETELA DEL VOLCÁN	Municipal	Ejecutivo	f	f	t	f	f	f	{"nombre": "Morelos"}	Tetela del Volcán	2025-07-09 17:12:28.799	2025-07-09 17:12:28.799
95	MUNICIPIO DE TLALNEPANTLA	Municipal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	Tlalnepantla	2025-07-09 17:13:02.587	2025-07-09 17:13:02.587
96	MUNICIPIO DE TLALTIZAPÁN	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Tlaltizapán de Zapata	2025-07-09 17:13:23.367	2025-07-09 17:13:23.367
97	MUNICIPIO DE TLAQUILTENANGO	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Tlaquiltenango	2025-07-09 17:13:57.224	2025-07-09 17:13:57.224
99	MUNICIPIO DE TLAYACAPAN	Municipal	Ejecutivo	f	f	t	f	f	f	{"nombre": "Morelos"}	Tlayacapan	2025-07-09 17:16:26.175	2025-07-09 17:16:26.175
100	MUNICIPIO DE TOTOLAPAN	Municipal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	Totolapan	2025-07-09 17:16:51.112	2025-07-09 17:16:51.112
101	MUNICIPIO DE XOCHITEPEC	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Xochitepec	2025-07-09 17:17:16.519	2025-07-09 17:17:16.519
102	MUNICIPIO DE XOXOCOTLA	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Xoxocotla	2025-07-09 17:17:38.423	2025-07-09 17:17:38.423
103	MUNICIPIO DE YAUTEPEC	Municipal	Ejecutivo	f	f	f	f	f	f	{"nombre": "Morelos"}	Yautepec	2025-07-09 17:17:58.625	2025-07-09 17:17:58.625
104	MUNICIPIO DE YECAPIXTLA	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Yecapixtla	2025-07-09 17:18:18.806	2025-07-09 17:18:18.806
105	MUNICIPIO DE ZACATEPEC	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Zacatepec	2025-07-09 17:19:03.695	2025-07-09 17:19:03.695
106	MUNICIPIO DE ZACUALPAN DE AMILPAS	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Zacualpan de Amilpas	2025-07-09 17:19:28.631	2025-07-09 17:19:28.631
107	MUSEO MORELENSE DE ARTE POPULAR	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:20:12.349	2025-07-09 17:20:12.349
108	OFICINA DE LA GUBERNATURA DEL ESTADO	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:20:27.954	2025-07-09 17:20:27.954
109	OPERADOR DE CARRETERAS DE CUOTA	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:20:40.944	2025-07-09 17:20:40.944
110	PROCURADURÍA DE PROTECCIÓN AL AMBIENTE DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:20:54.494	2025-07-09 17:20:54.494
111	SECRETARIADO EJECUTIVO DEL SISTEMA ESTATAL DE SEGURIDAD PÚBLICA	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:21:07.507	2025-07-09 17:21:07.507
112	SECRETARÍA DE ADMINISTRACIÓN	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:21:20.541	2025-07-09 17:21:20.541
113	SECRETARÍA DE BIENESTAR	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:21:39.204	2025-07-09 17:21:39.204
114	SECRETARÍA DE CULTURA	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:21:51.128	2025-07-09 17:21:51.128
115	SECRETARÍA DE DESARROLLO AGROPECUARIO	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:22:06.297	2025-07-09 17:22:06.297
116	SECRETARÍA DE DESARROLLO ECONÓMICO Y DEL TRABAJO	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:22:18.787	2025-07-09 17:22:18.787
117	SECRETARÍA DE DESARROLLO SUSTENTABLE	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:22:42.769	2025-07-09 17:22:42.769
118	SECRETARÍA DE EDUCACIÓN	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:22:57.451	2025-07-09 17:22:57.451
119	SECRETARÍA DE GOBIERNO	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:25:06.262	2025-07-09 17:25:06.262
120	SECRETARÍA DE HACIENDA	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:25:25.914	2025-07-09 17:25:25.914
121	SECRETARÍA DE INFRAESTRUCTURA	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:25:40.422	2025-07-09 17:25:40.422
122	SECRETARÍA DE LA CONTRALORÍA	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:25:53.268	2025-07-09 17:25:53.268
123	SECRETARÍA DE LAS MUJERES	Estatal	Ejecutivo	f	f	f	f	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:26:07.824	2025-07-09 17:26:07.824
124	SECRETARÍA DE SALUD	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:26:20.535	2025-07-09 17:26:20.535
125	SECRETARÍA DE SEGURIDAD Y PROTECCIÓN CIUDADANA	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:26:34.74	2025-07-09 17:26:34.74
126	SECRETARÍA DE TURISMO	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:26:49.01	2025-07-09 17:26:49.01
127	SECRETARÍA EJECUTIVA DEL SISTEMA ANTICORRUPCIÓN DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	t	{"nombre": "Morelos"}	\N	2025-07-09 17:27:05.935	2025-07-09 17:27:05.935
128	SECRETARÍA EJECUTIVA DEL SISTEMA DE PROTECCIÓN INTEGRAL DE NIÑAS, NIÑOS Y ADOLESCENTES DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:27:20.639	2025-07-09 17:27:20.639
129	SERVICIOS DE SALUD DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:27:32.828	2025-07-09 17:27:32.828
130	SISTEMA DE AGUA POTABLE Y ALCANTARILLADO DEL MUNICIPIO DE CUERNAVACA	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Cuernavaca	2025-07-09 17:27:52.262	2025-07-09 17:27:52.262
131	SISTEMA DE AGUA POTABLE Y SANEAMIENTO DE YAUTEPEC	Municipal	Ejecutivo	f	f	f	f	f	f	{"nombre": "Morelos"}	Yautepec	2025-07-09 17:28:22.806	2025-07-09 17:28:22.807
132	SISTEMA DE CONSERVACIÓN AGUA POTABLE Y SANEAMIENTO DE EMILIANO ZAPATA	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Emiliano Zapata	2025-07-09 17:28:52.701	2025-07-09 17:28:52.701
133	SISTEMA DE CONSERVACIÓN AGUA POTABLE Y SANEAMIENTO DE PUENTE DE IXTLA	Municipal	Ejecutivo	f	f	t	f	f	f	{"nombre": "Morelos"}	Puente de Ixtla	2025-07-09 17:29:33.359	2025-07-09 17:29:33.359
134	SISTEMA DE CONSERVACIÓN AGUA POTABLE Y SANEAMIENTO DE TEMIXCO	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Temixco	2025-07-09 17:31:25.794	2025-07-09 17:31:25.794
135	SISTEMA DE CONSERVACIÓN AGUA POTABLE Y SANEAMIENTO DE ZACATEPEC	Municipal	Ejecutivo	f	f	t	f	f	f	{"nombre": "Morelos"}	Zacatepec	2025-07-09 17:31:50.903	2025-07-09 17:31:50.903
136	SISTEMA DE CONSERVACIÓN DE AGUA POTABLE Y SANEAMIENTO DE AGUA DE JIUTEPEC	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Jiutepec	2025-07-09 17:32:16.759	2025-07-09 17:32:16.759
137	SISTEMA MUNICIPAL DIF CUERNAVACA	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Cuernavaca	2025-07-09 17:32:44.418	2025-07-09 17:32:44.418
138	SISTEMA MUNICIPAL DIF DE ATLATLAHUCAN	Municipal	Ejecutivo	f	f	t	f	f	f	{"nombre": "Morelos"}	Atlatlahucan	2025-07-09 17:33:17.089	2025-07-09 17:33:17.089
139	SISTEMA MUNICIPAL DIF DE EMILIANO ZAPATA	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Emiliano Zapata	2025-07-09 17:33:38.847	2025-07-09 17:33:38.847
140	SISTEMA MUNICIPAL DIF DE JIUTEPEC	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Jiutepec	2025-07-09 17:34:15.606	2025-07-09 17:34:15.606
141	SISTEMA MUNICIPAL DIF DE TEMIXCO	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Temixco	2025-07-09 17:34:38.717	2025-07-09 17:34:38.717
142	SISTEMA MUNICIPAL DIF DE TETECALA	Municipal	Ejecutivo	f	f	f	f	f	f	{"nombre": "Morelos"}	Tetecala	2025-07-09 17:35:21.147	2025-07-09 17:35:21.147
143	SISTEMA MUNICIPAL DIF DE XOCHITEPEC	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Xochitepec	2025-07-09 17:35:44.442	2025-07-09 17:35:44.442
144	SISTEMA OPERADOR DE AGUA POTABLE Y SANEAMIENTO DEL MUNICIPIO DE AYALA	Municipal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	Ayala	2025-07-09 17:36:03.186	2025-07-09 17:36:03.186
145	SISTEMA OPERADOR DE AGUA POTABLE Y SANEAMIENTO DEL MUNICIPIO DE CUAUTLA	Municipal	Ejecutivo	f	f	t	t	f	f	{"nombre": "Morelos"}	Cuautla	2025-07-09 17:36:26.913	2025-07-09 17:36:26.913
146	SISTEMA PARA EL DESARROLLO INTEGRAL DE LA FAMILIA DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:36:43.065	2025-07-09 17:36:43.065
147	TRIBUNAL DE JUSTICIA ADMINISTRATIVA DEL ESTADO DE MORELOS	Estatal	Judicial	f	f	t	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:37:05.684	2025-07-09 17:37:05.684
148	TRIBUNAL ELECTORAL DEL ESTADO DE MORELOS	Estatal	Judicial	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:37:27.215	2025-07-09 17:37:27.215
149	TRIBUNAL ESTATAL DE CONCILIACIÓN Y ARBITRAJE DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:37:50.89	2025-07-09 17:37:50.89
150	TRIBUNAL SUPERIOR DE JUSTICIA DEL ESTADO DE MORELOS	Estatal	Judicial	f	f	t	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:38:09.325	2025-07-09 17:38:09.325
151	TRIBUNAL UNITARIO DE JUSTICIA PENAL PARA ADOLESCENTES	Estatal	Judicial	f	f	t	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:38:27.137	2025-07-09 17:38:27.137
152	UNIVERSIDAD POLITÉCNICA DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:38:45.48	2025-07-09 17:38:45.48
153	UNIVERSIDAD TECNOLÓGICA DEL SUR DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:38:59.249	2025-07-09 17:38:59.249
154	UNIVERSIDAD TECNOLÓGICA EMILIANO ZAPATA DEL ESTADO DE MORELOS	Estatal	Ejecutivo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:39:14.005	2025-07-09 17:39:14.005
155	UNIVERSIDAD AUTONOMA DEL ESTADO DE MORELOS	Estatal	Autónomo	f	f	f	t	f	f	{"nombre": "Morelos"}	\N	2025-07-09 17:39:30.66	2025-07-09 17:39:30.66
156	MUNICIPIO DE AMACUZAC	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Amacuzac	2025-07-09 18:25:45.951	2025-07-09 18:25:45.951
158	MUNICIPIO DE AXOCHIAPAN	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Axochiapan	2025-07-09 18:26:20.625	2025-07-09 18:26:20.625
159	MUNICIPIO DE AYALA	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Ayala	2025-07-09 18:27:07.062	2025-07-09 18:27:07.062
160	MUNICIPIO DE COATETELCO	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Coatetelco	2025-07-09 18:27:24.206	2025-07-09 18:27:24.206
161	MUNICIPIO DE COATLÁN DEL RÍO	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Coatlán del Río	2025-07-09 18:27:47.241	2025-07-09 18:27:47.241
162	MUNICIPIO DE CUAUTLA	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Cuautla	2025-07-09 18:28:08.676	2025-07-09 18:28:08.676
163	MUNICIPIO DE CUERNAVACA	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Cuernavaca	2025-07-09 18:28:27.058	2025-07-09 18:28:27.058
164	MUNICIPIO DE EMILIANO ZAPATA	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Emiliano Zapata	2025-07-09 18:28:48.156	2025-07-09 18:28:48.156
165	MUNICIPIO DE HUEYAPAN	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Hueyapan	2025-07-09 18:29:06.375	2025-07-09 18:29:06.375
166	MUNICIPIO DE HUITZILAC	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Huitzilac	2025-07-09 18:29:23.973	2025-07-09 18:29:23.973
167	MUNICIPIO DE JANTETELCO	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Jantetelco	2025-07-09 18:29:40.055	2025-07-09 18:29:40.055
168	MUNICIPIO DE JIUTEPEC	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Jiutepec	2025-07-09 18:29:58.21	2025-07-09 18:29:58.21
169	MUNICIPIO DE JOJUTLA	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Jojutla	2025-07-09 18:30:19.713	2025-07-09 18:30:19.713
170	MUNICIPIO DE JONACATEPEC	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Jonacatepec de Leandro Valle	2025-07-09 18:30:42.081	2025-07-09 18:30:42.081
171	MUNICIPIO DE MAZATEPEC	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Mazatepec	2025-07-09 18:30:59.934	2025-07-09 18:30:59.934
172	MUNICIPIO DE MIACATLÁN	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Miacatlán	2025-07-09 18:31:18.546	2025-07-09 18:31:18.546
173	MUNICIPIO DE OCUITUCO	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Ocuituco	2025-07-09 18:31:36.217	2025-07-09 18:31:36.217
174	MUNICIPIO DE PUENTE DE IXTLA	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Puente de Ixtla	2025-07-09 18:32:02.865	2025-07-09 18:32:02.865
175	MUNICIPIO DE TEMIXCO	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Temixco	2025-07-09 18:32:24.749	2025-07-09 18:32:24.749
176	MUNICIPIO DE TEMOAC	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Temoac	2025-07-09 18:32:49.089	2025-07-09 18:32:49.089
177	MUNICIPIO DE TEPALCINGO	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Tepalcingo	2025-07-09 18:33:08.871	2025-07-09 18:33:08.871
178	MUNICIPIO DE TEPOZTLÁN	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Tepoztlán	2025-07-09 18:33:27.59	2025-07-09 18:33:27.59
179	MUNICIPIO DE TETECALA	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Tetecala	2025-07-09 18:33:45.758	2025-07-09 18:33:45.758
180	MUNICIPIO DE TETELA DEL VOLCÁN	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Tetela del Volcán	2025-07-09 18:34:05.295	2025-07-09 18:34:05.295
181	MUNICIPIO DE TLALNEPANTLA	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Tlalnepantla	2025-07-09 18:34:23.618	2025-07-09 18:34:23.618
182	MUNICIPIO DE TLALTIZAPÁN	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Tlaltizapán de Zapata	2025-07-09 18:34:45.734	2025-07-09 18:34:45.734
183	MUNICIPIO DE TLAQUILTENANGO	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Tlaquiltenango	2025-07-09 18:35:04.85	2025-07-09 18:35:04.85
184	MUNICIPIO DE TLAYACAPAN	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Tlayacapan	2025-07-09 18:58:54.723	2025-07-09 18:58:54.723
185	MUNICIPIO DE TOTOLAPAN	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Totolapan	2025-07-09 18:59:26.911	2025-07-09 18:59:26.911
186	MUNICIPIO DE XOCHITEPEC	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Xochitepec	2025-07-09 18:59:44.685	2025-07-09 18:59:44.685
187	MUNICIPIO DE XOXOCOTLA	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Xoxocotla	2025-07-09 19:00:06.161	2025-07-09 19:00:06.161
188	MUNICIPIO DE YAUTEPEC	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Yautepec	2025-07-09 19:00:24.599	2025-07-09 19:00:24.599
189	MUNICIPIO DE YECAPIXTLA	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Yecapixtla	2025-07-09 19:00:44.615	2025-07-09 19:00:44.615
190	MUNICIPIO DE ZACATEPEC	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Zacatepec	2025-07-09 19:01:00.051	2025-07-09 19:01:00.051
191	MUNICIPIO DE ZACUALPAN DE AMILPAS	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Zacualpan de Amilpas	2025-07-09 19:01:25.138	2025-07-09 19:01:25.138
192	MUNICIPIO DE ATLATLAHUCAN	Municipal	Ejecutivo	t	f	f	f	f	f	{"nombre": "Morelos"}	Atlatlahucan	2025-07-09 19:23:20.805	2025-07-09 19:23:20.805
193	SISTEMA MUNICIPAL DIF AYALA	Municipal	Ejecutivo	f	f	f	f	f	f	{"nombre": "Morelos"}	Ayala	2025-07-10 18:03:59.787	2025-07-10 18:03:59.787
194	SISTEMA MUNICIPAL DIF ZACATEPEC	Municipal	Ejecutivo	f	f	f	f	f	f	{"nombre": "Morelos"}	Zacatepec	2025-07-10 18:04:22.132	2025-07-10 18:04:22.132
\.


--
-- TOC entry 3421 (class 0 OID 16579)
-- Dependencies: 220
-- Data for Name: seguimientos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seguimientos (id, "acuerdoId", seguimiento, accion, "fechaSeguimiento", "fechaCreacion", "fechaActualizacion", "creadoPor") FROM stdin;
3	3	Recabación de documentación	Recabación de documentación	2025-01-22 00:00:00	2025-07-07 17:29:32.118	2025-07-07 17:29:32.118	\N
4	3	Recabación de firmas de los Integrantes del Comité Coordinador	Recabación de firmas de los Integrantes del Comité Coordinador	2025-02-17 00:00:00	2025-07-07 17:33:49.265	2025-07-07 17:33:49.265	\N
5	9	A Presentarse en la Siguiente Sesión Ordinaria del Órgano de Gobierno de la SESAEM.	A Presentarse en la Siguiente Sesión Ordinaria del Órgano de Gobierno de la SESAEM.	2025-07-08 00:00:00	2025-07-07 20:59:20.093	2025-07-07 20:59:20.093	\N
6	10	Se presenta propuesta de oficio al Presidente del Comité Coordinador, dirigido a la Gobernadora Margarita González Sarabia, solicitando fungiera como deudora solidaria, derivado del dictamen del Instituto Mexicano del Seguro Social, mismo Oficio fue emitido por la Presidencia del H. Tribunal Superior de Justicia con No. PRESIDENCIA/LJGO/198/2025 de fecha 08 de abril de 2025 .	Se presenta propuesta de oficio al Presidente del Comité Coordinador, dirigido a la Gobernadora Margarita González Sarabia, solicitando fungiera como deudora solidaria, derivado del dictamen del Instituto Mexicano del Seguro Social, mismo Oficio fue emitido por la Presidencia del H. Tribunal Superior de Justicia con No. PRESIDENCIA/LJGO/198/2025 de fecha 08 de abril de 2025 .	2025-04-08 00:00:00	2025-07-07 21:04:36.843	2025-07-07 21:06:52.129	\N
7	11	Se emitió oficio SESAEM/ST/473/2025, de fecha 28 de febrero, dirigido a la Dip. Jazmin Juana Solano López, Presidenta de la LVI legislatura del Congreso del Estado de Morelos, solicitando lleve a cabo las acciones que permitan constituir la Comisión de Selección, para a su vez, llevar a cabo la integración del Comité de Participación Ciudadana.	Se emitió oficio SESAEM/ST/473/2025, de fecha 28 de febrero, dirigido a la Dip. Jazmin Juana Solano López, Presidenta de la LVI legislatura del Congreso del Estado de Morelos, solicitando lleve a cabo las acciones que permitan constituir la Comisión de Selección, para a su vez, llevar a cabo la integración del Comité de Participación Ciudadana.	2025-02-28 00:00:00	2025-07-07 21:09:25.964	2025-07-07 21:09:25.964	\N
8	12	La secretaría Ejecutiva del Sistema Anticorrupción del Estado de Morelos, cada semana realiza Cápsula Informativa, la cual es compartida a los Enlaces de los Titulares, para su apoyo en la difusión de las mismas. Así como las actividades relevantes que sean realizadas	"facebook: https://www.facebook.com/sesaemorelos?locale=es_LA Instagram: https://www.instagram.com/saemorelos?igsh=am45MHgxajdteDUw X: https://x.com/SAEMorelos?t=Ljy_QHrmrvJBsNiWvWOjFQ&s=08"	2025-07-07 00:00:00	2025-07-07 21:13:43.885	2025-07-07 21:13:43.885	\N
9	13	Recabación de documentación	Recabación de documentación	2025-01-22 00:00:00	2025-07-07 21:23:08.971	2025-07-07 21:25:38.758	\N
10	13	Recabación de firmas de los Integrantes del Comité Coordinador	Recabación de firmas de los Integrantes del Comité Coordinador	2025-02-16 00:00:00	2025-07-07 21:26:18	2025-07-07 21:26:18	\N
11	13	Publicación en el Periodico Oficial "Tierra y Libertad"	http://periodico.morelos.gob.mx/obtenerPDF/2025/6409.pdf 	2025-03-19 00:00:00	2025-07-07 21:27:01.969	2025-07-07 21:27:01.969	\N
\.


--
-- TOC entry 3423 (class 0 OID 16590)
-- Dependencies: 222
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usuarios (id, email, nombre, apellido, password, rol, activo, "ultimoAcceso", "createdAt", "updatedAt") FROM stdin;
2	admin@saem.gob.mx	Administrador	Sistema	$2b$12$1.zqAG4tVrBg.1YExDfI/eE7IzNE0HLbbShsA3MwqFR2.qbmEqqmO	ADMINISTRADOR	t	2025-07-04 21:39:29.89	2025-07-04 19:18:59.219	2025-07-04 21:03:54.747
3	juan.landa@saem.gob.mx	Juan Manuel	Landa Vélez	$2b$12$rnO4MAPyYnl/hIqN7kc9Q.wXJlw3O5rwwVnaT//aN5kiTEKFuoSDm	ADMINISTRADOR	t	2025-08-07 16:50:06.004	2025-07-04 21:04:42.411	2025-07-04 21:05:04.467
6	karen.esparza@saem.gob.mx	Karen 	Esparza	$2b$12$hM6GGvnV6Whv3GAN7AnDyOCPEeEOqF6sjLCyRtbOBP/NMV5O2sOp.	OPERATIVO	t	2025-07-09 16:25:14.561	2025-07-09 16:24:53.209	2025-07-09 16:24:53.209
4	daniela.madrigal@saem.gob.mx	Daniela	Madrigal	$2b$12$9dmVEjXecjllneGS0iRng.Cyo5MzzZOIC26xJaMBm.YNcR8.P5l8q	SEGUIMIENTO	t	2025-07-18 21:30:19.91	2025-07-07 14:55:37.361	2025-07-07 14:55:37.361
7	diego.jasso@saem.gob.mx	Diego	Jasso	$2b$12$SV00uF/Py2E5bUrh58vP0unYhdnaRhqST/L4LzLtiAi6iInEQz9Ie	OPERATIVO	t	2025-08-04 21:57:35.239	2025-08-04 21:33:48.536	2025-08-04 21:33:48.536
\.


--
-- TOC entry 3443 (class 0 OID 0)
-- Dependencies: 209
-- Name: acuerdos_seguimiento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.acuerdos_seguimiento_id_seq', 17, true);


--
-- TOC entry 3444 (class 0 OID 0)
-- Dependencies: 223
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 44, true);


--
-- TOC entry 3445 (class 0 OID 0)
-- Dependencies: 225
-- Name: diagnosticos_entes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.diagnosticos_entes_id_seq', 9, true);


--
-- TOC entry 3446 (class 0 OID 0)
-- Dependencies: 211
-- Name: diagnosticos_municipales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.diagnosticos_municipales_id_seq', 115, true);


--
-- TOC entry 3447 (class 0 OID 0)
-- Dependencies: 215
-- Name: directorio_oic_entes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.directorio_oic_entes_id_seq', 37, true);


--
-- TOC entry 3448 (class 0 OID 0)
-- Dependencies: 213
-- Name: directorio_oic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.directorio_oic_id_seq', 36, true);


--
-- TOC entry 3449 (class 0 OID 0)
-- Dependencies: 217
-- Name: entes_publicos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.entes_publicos_id_seq', 194, true);


--
-- TOC entry 3450 (class 0 OID 0)
-- Dependencies: 219
-- Name: seguimientos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.seguimientos_id_seq', 11, true);


--
-- TOC entry 3451 (class 0 OID 0)
-- Dependencies: 221
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 7, true);


--
-- TOC entry 3246 (class 2606 OID 16533)
-- Name: acuerdos_seguimiento acuerdos_seguimiento_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acuerdos_seguimiento
    ADD CONSTRAINT acuerdos_seguimiento_pkey PRIMARY KEY (id);


--
-- TOC entry 3263 (class 2606 OID 16610)
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3266 (class 2606 OID 32893)
-- Name: diagnosticos_entes diagnosticos_entes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diagnosticos_entes
    ADD CONSTRAINT diagnosticos_entes_pkey PRIMARY KEY (id);


--
-- TOC entry 3248 (class 2606 OID 16544)
-- Name: diagnosticos_municipales diagnosticos_municipales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diagnosticos_municipales
    ADD CONSTRAINT diagnosticos_municipales_pkey PRIMARY KEY (id);


--
-- TOC entry 3253 (class 2606 OID 16561)
-- Name: directorio_oic_entes directorio_oic_entes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directorio_oic_entes
    ADD CONSTRAINT directorio_oic_entes_pkey PRIMARY KEY (id);


--
-- TOC entry 3250 (class 2606 OID 16554)
-- Name: directorio_oic directorio_oic_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directorio_oic
    ADD CONSTRAINT directorio_oic_pkey PRIMARY KEY (id);


--
-- TOC entry 3255 (class 2606 OID 16577)
-- Name: entes_publicos entes_publicos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entes_publicos
    ADD CONSTRAINT entes_publicos_pkey PRIMARY KEY (id);


--
-- TOC entry 3258 (class 2606 OID 16588)
-- Name: seguimientos seguimientos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seguimientos
    ADD CONSTRAINT seguimientos_pkey PRIMARY KEY (id);


--
-- TOC entry 3261 (class 2606 OID 16600)
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- TOC entry 3264 (class 1259 OID 24692)
-- Name: audit_logs_usuario_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_usuario_id_idx ON public.audit_logs USING btree (usuario_id);


--
-- TOC entry 3251 (class 1259 OID 16611)
-- Name: directorio_oic_entes_directorioOICId_entePublicoId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "directorio_oic_entes_directorioOICId_entePublicoId_key" ON public.directorio_oic_entes USING btree ("directorioOICId", "entePublicoId");


--
-- TOC entry 3256 (class 1259 OID 24691)
-- Name: seguimientos_acuerdoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "seguimientos_acuerdoId_idx" ON public.seguimientos USING btree ("acuerdoId");


--
-- TOC entry 3259 (class 1259 OID 16612)
-- Name: usuarios_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX usuarios_email_key ON public.usuarios USING btree (email);


--
-- TOC entry 3270 (class 2606 OID 16628)
-- Name: audit_logs audit_logs_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3267 (class 2606 OID 16613)
-- Name: directorio_oic_entes directorio_oic_entes_directorioOICId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directorio_oic_entes
    ADD CONSTRAINT "directorio_oic_entes_directorioOICId_fkey" FOREIGN KEY ("directorioOICId") REFERENCES public.directorio_oic(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3268 (class 2606 OID 16618)
-- Name: directorio_oic_entes directorio_oic_entes_entePublicoId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directorio_oic_entes
    ADD CONSTRAINT "directorio_oic_entes_entePublicoId_fkey" FOREIGN KEY ("entePublicoId") REFERENCES public.entes_publicos(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3269 (class 2606 OID 16623)
-- Name: seguimientos seguimientos_acuerdoId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seguimientos
    ADD CONSTRAINT "seguimientos_acuerdoId_fkey" FOREIGN KEY ("acuerdoId") REFERENCES public.acuerdos_seguimiento(id) ON UPDATE CASCADE ON DELETE CASCADE;


-- Completed on 2025-08-07 18:17:47 UTC

--
-- PostgreSQL database dump complete
--

